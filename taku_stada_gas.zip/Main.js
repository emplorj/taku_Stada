/**
 * Google Apps Script メインエントリポイント
 * リクエストのツール名に応じて各APIファイル（Satasupe, Nechronica 等）へ振り分けます。
 */

function doGet(e) {
  const params = (e && e.parameter) || {};
  const tool = params.tool || "";
  const action = params.action || "load";

  // ツールごとの分岐
  if (tool === "nechronica") {
    return createJsonResponse(handleNechronicaGet(action, e));
  }
  if (tool === "satasupe") {
    return createJsonResponse(handleSatasupeGet(action, e));
  }
  if (tool === "ar2e") {
    return createJsonResponse(handleAR2EGet(action, e));
  }
  if (tool === "dx3enemy") {
    return createJsonResponse(handleDX3EnemyGet(action, e));
  }

  // 従来のComboData/Shinjuku等の処理（ComboDataAPI.js内に維持）
  if (action === "import") {
    return importFromHokanjo(e);
  } else {
    if (tool === "shinjuku") {
      if (action === "list") {
        return getShinjukuList();
      } else {
        return loadFromDatabaseShinjuku(e);
      }
    } else if (tool === "logScene") {
      return loadLogSceneFromDatabase(e);
    } else {
      // デフォルトはComboDataのロード
      return loadFromDatabase(e);
    }
  }
}

function doPost(e) {
  let response;
  try {
    const payload = JSON.parse(e.postData.contents);

    // ツールごとの分岐
    if (payload.tool === "nechronica") {
      response = handleNechronicaPost(payload);
    } else if (payload.tool === "satasupe") {
      response = handleSatasupePost(payload);
    } else if (payload.tool === "ar2e") {
      response = handleAR2EPost(payload);
    } else if (payload.tool === "dx3enemy") {
      response = handleDX3EnemyPost(payload);
    } else if (payload.tool === "comboGenerator") {
      response = handleComboGeneratorRequest(payload);
    } else if (payload.tool === "komaMaker") {
      response = processSheetData(payload.data);
    } else if (payload.tool === "shinjuku") {
      response = handleShinjukuRequest(payload);
    } else if (payload.tool === "logScene") {
      response = handleLogSceneRequest(payload);
    } else {
      throw new Error("無効なツールリクエストです。");
    }

    return createJsonResponse(response);
  } catch (error) {
    if (typeof Logger !== 'undefined') Logger.log("Critical error in doPost: " + error.stack);
    return createJsonResponse({
      status: "error",
      message: "サーバー側エラー: " + error.message,
    });
  }
}

/**
 * 共通レスポンス返却関数
 */
function createJsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(
    ContentService.MimeType.JSON,
  );
}
