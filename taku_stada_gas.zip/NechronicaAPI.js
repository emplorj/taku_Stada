// ===== Nechronica API =====
const SHEET_NAME_NECHRONICA = "nechronica_enemies";
const TOOL_NAME_NECHRONICA = "nechronica";
const NECHRONICA_HEADERS = [
  "ID",
  "author",
  "name",
  "class_type",
  "is_public",
  "memo",
  "data",
  "icon_url",
  "time",
];

function handleNechronicaGet(action, e) {
  if (action === "listNechronicaEnemies") {
    return listNechronicaEnemies_(e);
  }
  if (action === "getNechronicaEnemyDetail") {
    return getNechronicaEnemyDetail_(e);
  }
  if (action === "deleteNechronicaEnemy") {
    return deleteNechronicaEnemy_(e);
  }
  return {
    status: "error",
    message: `nechronica用の不正なactionです: ${action}`,
  };
}

function handleNechronicaPost(payload) {
  const action = String((payload && payload.action) || "").trim();
  if (action === "saveNechronicaEnemy") {
    return saveNechronicaEnemy_(payload);
  }
  return {
    status: "error",
    message: `nechronica用の不正なactionです: ${action}`,
  };
}

function getNechronicaSheet_() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = spreadsheet.getSheetByName(SHEET_NAME_NECHRONICA);
  if (!sheet) sheet = spreadsheet.insertSheet(SHEET_NAME_NECHRONICA);
  ensureNechronicaHeaders_(sheet);
  return sheet;
}

function ensureNechronicaHeaders_(sheet) {
  if (sheet.getMaxColumns() < NECHRONICA_HEADERS.length) {
    sheet.insertColumnsAfter(
      sheet.getMaxColumns(),
      NECHRONICA_HEADERS.length - sheet.getMaxColumns(),
    );
  }
  const row =
    sheet.getLastRow() >= 1
      ? sheet.getRange(1, 1, 1, NECHRONICA_HEADERS.length).getValues()[0]
      : [];
  const hasHeader = NECHRONICA_HEADERS.every(
    (name, idx) => String(row[idx] || "") === name,
  );
  if (!hasHeader) {
    sheet
      .getRange(1, 1, 1, NECHRONICA_HEADERS.length)
      .setValues([NECHRONICA_HEADERS]);
  }
}

function getNechronicaHeaderMap_(sheet) {
  const row =
    sheet.getRange(1, 1, 1, NECHRONICA_HEADERS.length).getValues()[0] || [];
  const map = {};
  NECHRONICA_HEADERS.forEach((name, idx) => {
    const actual = String(row[idx] || name);
    map[actual] = idx;
    if (actual !== name && map[name] == null) map[name] = idx;
  });
  return map;
}

function parseBool_(v) {
  if (typeof v === "boolean") return v;
  const s = String(v || "")
    .trim()
    .toLowerCase();
  return s === "true" || s === "1" || s === "yes" || s === "on" || s === "公開";
}

function safeJson_(text, fallback) {
  try {
    return JSON.parse(text);
  } catch (_e) {
    return fallback;
  }
}

function nowNechronicaTimeText_() {
  const tz = Session.getScriptTimeZone() || "Asia/Tokyo";
  return Utilities.formatDate(new Date(), tz, "yyyy/MM/dd HH:mm:ss");
}

function isSequentialNechronicaId_(value) {
  const s = String(value || "").trim();
  if (!/^\d+$/.test(s)) return false;
  const n = Number(s);
  return Number.isFinite(n) && n > 0 && n < 1000000000000;
}

function getNextNechronicaSequentialId_(sheet, map) {
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return "1";
  const idCol = (map.ID != null ? map.ID : 0) + 1;
  const ids = sheet.getRange(2, idCol, lastRow - 1, 1).getValues();
  let maxId = 0;
  for (let i = 0; i < ids.length; i += 1) {
    const raw = ids[i][0];
    if (!isSequentialNechronicaId_(raw)) continue;
    const n = Number(raw);
    if (n > maxId) maxId = n;
  }
  return String(maxId + 1);
}

function normalizeNechronicaEnemy_(enemy) {
  const src = enemy && typeof enemy === "object" ? enemy : {};
  const now = nowNechronicaTimeText_();
  return {
    ID: String(src.ID || "").trim(),
    author: String(src.author || "").trim(),
    name: String(src.name || "").trim(),
    class_type: String(src.class_type || "サヴァント").trim() || "サヴァント",
    is_public: !!src.is_public,
    memo: String(src.memo || ""),
    data:
      src.data && typeof src.data === "object"
        ? src.data
        : { parts: [], maneuvers: [] },
    icon_url: String(src.icon_url || "").trim(),
    time: String(src.time || "").trim() || now,
  };
}

function nechronicaEnemyToRow_(enemy) {
  return [
    enemy.ID,
    enemy.author,
    enemy.name,
    enemy.class_type,
    enemy.is_public ? "true" : "false",
    enemy.memo,
    JSON.stringify(enemy.data || {}),
    enemy.icon_url,
    enemy.time,
  ];
}

function rowToNechronicaEnemy_(row, map) {
  const pick = (name) => row[map[name] != null ? map[name] : -1];
  return {
    ID: String(pick("ID") || "").trim(),
    author: String(pick("author") || "").trim(),
    name: String(pick("name") || "").trim(),
    class_type: String(pick("class_type") || "").trim() || "サヴァント",
    is_public: parseBool_(pick("is_public")),
    memo: String(pick("memo") || ""),
    data: safeJson_(String(pick("data") || "{}"), {
      parts: [],
      maneuvers: [],
    }),
    icon_url: String(pick("icon_url") || "").trim(),
    time: String(pick("time") || "").trim(),
  };
}

function listNechronicaEnemies_(e) {
  const author = String((e && e.parameter && e.parameter.author) || "").trim();
  const params = (e && e.parameter) || {};
  const isAdminMode =
    String(params.admin || params.adminCode || "").trim() === "9800" &&
    (String(params.allAuthors || "").trim() === "1" ||
      String(params.includePrivate || "").trim() === "1");
  const sheet = getNechronicaSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { status: "success", data: [] };

  const map = getNechronicaHeaderMap_(sheet);
  const rows = sheet
    .getRange(2, 1, lastRow - 1, NECHRONICA_HEADERS.length)
    .getValues()
    .map((row) => rowToNechronicaEnemy_(row, map))
    .filter((enemy) => {
      if (!enemy.ID) return false;
      if (isAdminMode) return true;
      if (enemy.is_public) return true;
      return author && enemy.author === author;
    })
    .sort((a, b) => String(b.time || "").localeCompare(String(a.time || "")));

  return { status: "success", data: rows };
}

function getNechronicaEnemyDetail_(e) {
  const enemyId = String(
    (e && e.parameter && e.parameter.enemyId) || "",
  ).trim();
  const author = String((e && e.parameter && e.parameter.author) || "").trim();
  if (!enemyId)
    return { status: "error", message: "enemyId パラメータが必要です。" };

  const sheet = getNechronicaSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1)
    return { status: "error", message: "対象データが見つかりません。" };

  const map = getNechronicaHeaderMap_(sheet);
  const found = sheet
    .getRange(2, 1, lastRow - 1, NECHRONICA_HEADERS.length)
    .getValues()
    .map((row) => rowToNechronicaEnemy_(row, map))
    .find((enemy) => enemy.ID === enemyId);
  if (!found)
    return { status: "error", message: "指定IDのエネミーが見つかりません。" };

  if (!found.is_public && (!author || found.author !== author)) {
    return { status: "error", message: "非公開データの取得権限がありません。" };
  }

  return { status: "success", data: found };
}

function saveNechronicaEnemy_(payload) {
  const enemy = normalizeNechronicaEnemy_(payload && payload.enemy);
  enemy.time = nowNechronicaTimeText_();

  const sheet = getNechronicaSheet_();
  const map = getNechronicaHeaderMap_(sheet);
  if (!isSequentialNechronicaId_(enemy.ID)) {
    enemy.ID = getNextNechronicaSequentialId_(sheet, map);
  }
  const idCol = (map.ID != null ? map.ID : 0) + 1;
  const lastRow = sheet.getLastRow();
  let targetRow = -1;
  if (lastRow > 1) {
    const ids = sheet.getRange(2, idCol, lastRow - 1, 1).getValues();
    for (let i = 0; i < ids.length; i += 1) {
      if (String(ids[i][0] || "").trim() === enemy.ID) {
        targetRow = i + 2;
        break;
      }
    }
  }

  const row = nechronicaEnemyToRow_(enemy);
  if (targetRow > 0) {
    sheet.getRange(targetRow, 1, 1, NECHRONICA_HEADERS.length).setValues([row]);
  } else {
    sheet.appendRow(row);
  }

  return { status: "success", message: "保存しました", data: enemy };
}

function deleteNechronicaEnemy_(e) {
  const id = String((e && e.parameter && e.parameter.id) || "").trim();
  if (!id) return { status: "error", message: "IDが必要です" };

  const sheet = getNechronicaSheet_();
  const map = getNechronicaHeaderMap_(sheet);
  const idCol = (map.ID != null ? map.ID : 0) + 1;
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { status: "error", message: "データがありません" };

  const ids = sheet.getRange(2, idCol, lastRow - 1, 1).getValues();
  let targetRow = -1;
  for (let i = 0; i < ids.length; i += 1) {
    if (String(ids[i][0] || "").trim() === id) {
      targetRow = i + 2;
      break;
    }
  }

  if (targetRow > 0) {
    sheet.deleteRow(targetRow);
    return { status: "success", message: "削除しました" };
  }
  return { status: "error", message: "対象が見つかりませんでした" };
}
