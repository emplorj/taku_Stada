// ===== 設定項目 =====
const SHEET_NAME = 'ルルブtier'; 

// 列番号を定数として定義 (A列=1, B列=2...)
const SYSTEM_COL = 1;         // A列: system
const RANK_ORDER_COL = 2;     // B列: rankOrder
const TITLE_COL = 3;          // C列: title
const CATEGORY_COL = 4;       // D列: category
const PRICE_COL = 5;          // E列: price
const RELEASE_DATE_COL = 6;   // F列: releaseDate
const IMAGE_URL_COL = 7;      // G列: imageUrl
const OFFICIAL_INFO_COL = 8;  // H列: official_info
const INFO_COL = 9;           // I列: info (手動入力用)
const ABBREVIATION_COL = 10;  // J列: abbreviation (手動入力用)
const BOOK_URL_COL = 11;      // K列: bookUrl

// ===== ここから下は変更不要 =====

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('Tierリスト管理')
    .addItem('【選択行】の情報を強制更新', 'updateSelectedRows')
    .addSeparator()
    .addItem('【全行】の未入力情報を更新', 'updateAllEmptyRows')
    .addToUi();
}

/**
 * 修正版：選択範囲の列数に関係なく、選択された「行」のA列～K列を取得して処理する
 */
function updateSelectedRows() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  if (!sheet) return;
  
  // ユーザーが選択している範囲を取得
  const activeRange = sheet.getActiveRange();
  const startRow = activeRange.getRow();
  const numRows = activeRange.getNumRows();

  // ★修正ポイント
  // ユーザーが「A1:L3（12列）」を選んでいても、「C5（1セル）」を選んでいても、
  // その行の「1列目(A) ～ 11列目(BOOK_URL_COL)」を正式な範囲として再定義する
  const range = sheet.getRange(startRow, 1, numRows, BOOK_URL_COL);
  
  processRange(sheet, range, false); 
}

function updateAllEmptyRows() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  if (!sheet) return;
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return;
  // ここも強制的に1列目から指定しているのでOK
  const range = sheet.getRange(2, 1, lastRow - 1, BOOK_URL_COL);
  processRange(sheet, range, true);
}

function processRange(sheet, range, onlyUpdateEmpty) {
  const startRow = range.getRow();
  const numRows = range.getNumRows();
  const values = range.getValues();

  for (let i = 0; i < numRows; i++) {
    const currentRowValues = values[i];
    const bookUrl = currentRowValues[BOOK_URL_COL - 1];
    const titleValue = currentRowValues[TITLE_COL - 1]; 

    // URLがあり、かつ（強制更新モード または タイトルが空）の場合に実行
    if (bookUrl && (!onlyUpdateEmpty || !titleValue)) {
      try {
        const bookData = fetchBookData(bookUrl);
        
        currentRowValues[TITLE_COL - 1] = bookData.title;
        currentRowValues[CATEGORY_COL - 1] = bookData.category;
        currentRowValues[PRICE_COL - 1] = bookData.price;
        currentRowValues[RELEASE_DATE_COL - 1] = bookData.releaseDate;
        currentRowValues[IMAGE_URL_COL - 1] = bookData.imageUrl;
        currentRowValues[OFFICIAL_INFO_COL - 1] = bookData.official_info;
        
        // 書き込み時に範囲の列数を values の長さに合わせることでエラーを防ぐ
        // (基本的には updateSelectedRows で範囲を固定しているので安全だが、念のため)
        sheet.getRange(startRow + i, 1, 1, BOOK_URL_COL).setValues([currentRowValues]);
        
        SpreadsheetApp.flush();
        Utilities.sleep(1500); // サーバー負荷軽減のための待機
      } catch (e) {
        sheet.getRange(startRow + i, TITLE_COL).setValue(`取得エラー: ${e.message}`);
      }
    }
  }
}

/**
 * URLを判別し、サイトに応じたデータ取得関数を呼び出す
 */
function fetchBookData(url) {
  const options = { 'muteHttpExceptions': true, 'headers': {'User-Agent': 'Mozilla/5.0'} };
  const response = UrlFetchApp.fetch(url, options);
  
  if (response.getResponseCode() !== 200) {
    throw new Error(`HTTP ${response.getResponseCode()}`);
  }
  
  const html = response.getContentText();
  let rawData;

  if (url.includes('bookwalker.jp')) {
    rawData = fetchBookWalkerData(html);
  } else if (url.includes('amazon.co.jp')) {
    rawData = fetchAmazonData(html);
  } else {
    throw new Error('非対応のURLです(BookWalker/Amazonのみ)');
  }
  
  return cleanUpTitleAndCategory(rawData);
}

/**
 * BookWalkerのHTMLからデータを抽出する（修正版）
 */
function fetchBookWalkerData(html) {
  // 1. タイトル
  const titleMatch = html.match(/<h1 class="t-c-product-main-data__title">([\s\S]*?)<\/h1>/);
  const fullTitle = titleMatch ? titleMatch[1].trim().replace(/&amp;/g, '&') : '（タイトル取得失敗）';

  // 2. 書影URL
  // 基本はmetaタグから探すが、取れない場合は本文中の画像タグを探す保険を追加
  let imageUrl = '（画像URL取得失敗）';
  const ogImageMatch = html.match(/<meta property="og:image" content="([^"]+)">/);
  if (ogImageMatch) {
    imageUrl = ogImageMatch[1].trim();
  } else {
    // 保険：HTML本文からメイン画像のURLを探す
    const bodyImageMatch = html.match(/class="t-c-book-cover-main__thumbnail[^"]*".*?src="([^"]+)"/);
    if (bodyImageMatch) {
      imageUrl = bodyImageMatch[1].trim();
    }
  }
  
  // 3. 価格（★ここを修正）
  // 新しいクラス名: t-c-product-action-parts-price__value に対応
  let price = '（価格取得失敗）';
  const priceMatch = html.match(/class="t-c-product-action-parts-price__value"[^>]*>([\d,]+)/);
  if (priceMatch) {
      price = `${priceMatch[1]}円`;
  }
  
  // 4. 発行日
  const releaseDateMatch = html.match(/<dt>底本発行日<\/dt>\s*<dd>([^<]+)<\/dd>/);
  const releaseDate = releaseDateMatch ? releaseDateMatch[1].trim().replace(/\//g, '-') : '（発行日取得失敗）';

  // 5. 紹介文
  let official_info = '（紹介文取得失敗）';
  const synopsisMatch = html.match(/<section class="t-c-product-synopsis-main">([\s\S]*?)<\/section>/);
  if (synopsisMatch) {
      const synopsisHtml = synopsisMatch[1];
      // セクション内のすべての<p>タグの内容を取得して連結
      const paragraphs = synopsisHtml.match(/<p[^>]*>([\s\S]*?)<\/p>/g) || [];
      official_info = paragraphs
          .map(p => p.replace(/<br\s*\/?>/g, '\n').replace(/<[^>]+>/g, '').trim())
          // 著作権表記や空行を除外
          .filter(text => text && !text.startsWith('(C)') && !text.startsWith('（C）'))
          .join('\n');
  }
  
  return { 
      title: fullTitle, 
      official_info: official_info,
      price: price, 
      releaseDate: releaseDate,
      imageUrl: imageUrl
  };
}


function fetchAmazonData(html) {
  const titleMatch = html.match(/<span id="productTitle"[^>]*>([\s\S]*?)<\/span>/);
  const title = titleMatch ? titleMatch[1].trim().replace(/&/g, '&') : '（タイトル取得失敗）';

  const imageMatch = html.match(/<meta property="og:image" content="([^"]+)">/);
  const imageUrl = imageMatch ? imageMatch[1].trim() : '（画像URL取得失敗）';
  
  let price = '（価格取得失敗）';
  const priceMatches = [
    html.match(/<span class="a-offscreen">\s*￥([\d,]+)\s*<\/span>/),
    html.match(/<span id="price"[^>]*>￥([\d,]+)<\/span>/),
    html.match(/"priceToPay"\s*:\s*{"price"\s*:\s*([\d,]+)/),
    html.match(/<span class="kindle-price">.*?￥([\d,]+).*?<\/span>/),
    html.match(/id="priceinsidebuybox"[^>]*>￥([\d,]+)</)
  ];
  for (const pMatch of priceMatches) {
    if (pMatch && pMatch[1]) {
      price = `${pMatch[1]}円`;
      break;
    }
  }

  let releaseDate = '（発行日取得失敗）';
  const releaseDateMatch = html.match(/<div id="rpi-attribute-book_details-publication_date"[\s\S]*?<span>([\d\/]+)<\/span>/) || html.match(/<li><b>発売日<\/b>:\s*<span>(.*?)<\/span><\/li>/);
  if (releaseDateMatch && releaseDateMatch[1]) {
    releaseDate = releaseDateMatch[1].trim().replace(/\//g, '-');
  }
  
  let official_info = '（紹介文取得失敗）';
  const descMatch = html.match(/<div data-a-expander-name="book_description_expander"[\s\S]*?<div class="a-expander-content[\s\S]*?>([\s\S]*?)<\/div>/);
  if (descMatch && descMatch[1]) {
    official_info = descMatch[1]
      .replace(/<br\s*\/?>/g, '\n')
      .replace(/<[^>]+>/g, '')
      .trim();
  }

  return { 
      title: title,
      official_info: official_info,
      price: price, 
      releaseDate: releaseDate,
      imageUrl: imageUrl
  };
}

function cleanUpTitleAndCategory(rawData) {
  let cleanTitle = rawData.title;
  
  const removeKeywords = /ダブルクロス The 3rd Edition|ソード・ワールド2.5|【電子特典付き】|\(富士見ドラゴンブック\)|\(角川スニーカー文庫\)/g;
  cleanTitle = cleanTitle.replace(removeKeywords, '').trim();

  let category = '';
  const categoryKeywords = [
      'データ＆ルールブック', 'データ&ルールブック', 'ルール&データブック', 'シナリオ集', 
      'データ集', 'ステージ集', 'サプリメント', 'スタートガイド', 'ワールドガイド', 
      'シナリオブック', 'ルールブック', '追加データブック'
  ];
  for (const keyword of categoryKeywords) {
      if (cleanTitle.startsWith(keyword)) {
          category = keyword;
          cleanTitle = cleanTitle.substring(keyword.length).trim();
          break;
      }
  }

  rawData.title = cleanTitle;
  rawData.category = category;
  
  return rawData;
}