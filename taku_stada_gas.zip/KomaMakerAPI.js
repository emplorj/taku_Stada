// KomaMakerAPI.gs JSON unified version
// DX3 / Nechronica: https://charasheet.vampire-blood.net/[ID].js
// Satasupe: https://character-sheets.appspot.com/satasupe/display?ajax=1&key=...

// =================================================================================
// メイン処理
// =================================================================================
function processSheetData(formData) {
  try {
    const url = formData.sheet;
    const img = formData.img;
    const opt = [!formData.nomemo, !formData.nochp];
    const additionalPalette = formData.additionalPalette || "";

    if (!url || String(url).trim() === "") {
      return { message: "URLが入力されていない…だと…？", out: "URL未入力", eff: [[1, 2]] };
    }

    const fetchResult = fetchAndIdentifySystem(url);
    const system = fetchResult.system;
    const sheetData = fetchResult.sheetData;

    if (system === "Unknown") {
      throw new Error("対応していないキャラクターシート形式か、URLが間違っているようだ。");
    }

    let result = { message: "", out: "", eff: [[1, 2]] };
    let charaJson;
    let charName;

    switch (system) {
      case "DX3":
        charaJson = getDataDX(sheetData, url, img, opt, additionalPalette);
        charName = charaJson.data.name;
        result.message = `ククク、${charName}よ。任務に向かえ。`;
        result.eff = getEffectFromDxJson(sheetData);
        break;

      case "Nechronica":
        charaJson = getDataNC(sheetData, url, img, opt, additionalPalette);
        charName = charaJson.data.name;
        result.message = `${charName}、きみも、心を…取り戻したんだね`;
        break;

      case "Satasupe":
        charaJson = getDataSata(sheetData, url, img, opt, additionalPalette);
        charName = charaJson.data.name;
        result.message = `ククク、${charName}よ。涅槃で待つ`;
        result.itemLimits = getSatasupeItemLimits(sheetData);
        result.itemSections = getSatasupeItemSections(sheetData);
        break;

      default:
        throw new Error("システム処理中に不明なエラーが発生した。");
    }

    result.out = JSON.stringify(charaJson, null, 2);
    return result;
  } catch (error) {
    Logger.log("Error in processSheetData: " + error.stack);
    return {
      message: "処理中にエラーが発生したぞ: " + error.message,
      out: "エラー発生",
      eff: [[1, 2]],
    };
  }
}

// =================================================================================
// 共通ヘルパー
// =================================================================================
function fetchAndIdentifySystem(url) {
  const u = String(url || "");

  if (u.includes("character-sheets.appspot.com/satasupe")) {
    return { system: "Satasupe", sheetData: fetchSatasupeJson(u) };
  }

  if (u.includes("charasheet.vampire-blood.net")) {
    const sheetData = fetchCharasheetJson(u);
    const game = cleanText(sheetData.game).toLowerCase();

    if (game === "dx3" || game.indexOf("dx") >= 0) {
      return { system: "DX3", sheetData };
    }

    if (game === "nechro" || game === "nechronica" || game.indexOf("nechro") >= 0) {
      return { system: "Nechronica", sheetData };
    }

    // gameが空の古いデータ用の保険
    if (sheetData.NP1 !== undefined || sheetData.skill_tokugi !== undefined) {
      return { system: "DX3", sheetData };
    }
    if (sheetData.Act_Total !== undefined || sheetData.Power_name !== undefined) {
      return { system: "Nechronica", sheetData };
    }
  }

  throw new Error("対応していない、あるいは無効なURLです。");
}

function toCharasheetJsonUrl(url) {
  const m = String(url).match(/charasheet\.vampire-blood\.net\/(\d+)/);
  if (!m) throw new Error("キャラクター保管所のIDを取得できません。");
  return `https://charasheet.vampire-blood.net/${m[1]}.js`;
}

function fetchCharasheetJson(url) {
  const jsonUrl = toCharasheetJsonUrl(url);
  const text = UrlFetchApp.fetch(jsonUrl, { muteHttpExceptions: true }).getContentText("UTF-8");
  return parseMaybeJsonp(text);
}

function toSatasupeAjaxUrl(url) {
  const keyMatch = String(url).match(/[?&]key=([^&]+)/);
  if (!keyMatch) throw new Error("サタスペのkeyを取得できません。");
  return `https://character-sheets.appspot.com/satasupe/display?ajax=1&key=${keyMatch[1]}`;
}

function fetchSatasupeJson(url) {
  const ajaxUrl = toSatasupeAjaxUrl(url);
  const text = UrlFetchApp.fetch(ajaxUrl, { muteHttpExceptions: true }).getContentText("UTF-8");
  return parseMaybeJsonp(text);
}

function parseMaybeJsonp(text) {
  let s = String(text || "").trim();
  if (!s) throw new Error("JSONの取得結果が空です。");

  // JSONPや var x = {...}; 形式の保険
  const firstBrace = s.indexOf("{");
  const lastBrace = s.lastIndexOf("}");
  if (firstBrace > 0 && lastBrace > firstBrace) {
    s = s.slice(firstBrace, lastBrace + 1);
  }
  return JSON.parse(s);
}

function cleanText(value) {
  if (value === null || value === undefined) return "";
  return String(value)
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .trim();
}

function toZeroString(value) {
  const s = cleanText(value);
  return s === "" ? "0" : s;
}

function toInt(value, defVal) {
  const n = parseInt(cleanText(value), 10);
  return Number.isFinite(n) ? n : (defVal || 0);
}

function firstText() {
  for (let i = 0; i < arguments.length; i++) {
    const s = cleanText(arguments[i]);
    if (s) return s;
  }
  return "";
}

function arrayOrEmpty(value) {
  return Array.isArray(value) ? value : [];
}

function dedupeParams(params) {
  const seen = {};
  const result = [];
  params.forEach((p) => {
    if (!p || !p.label) return;
    if (seen[p.label]) return;
    seen[p.label] = true;
    result.push(p);
  });
  return result;
}

// 残しておく。JSON化後は通常使わないが、旧データ調査やフォールバック用。
function phantomJSCloudScraping(URL) {
  const key = PropertiesService.getScriptProperties().getProperty("PHANTOMJSCLOUD_ID");
  if (!key) throw new Error("PhantomJSCloudのAPIキーがスクリプトプロパティに設定されていません。");

  const option = { url: URL, renderType: "HTML", outputAsJson: true };
  const payload = encodeURIComponent(JSON.stringify(option));
  const apiUrl = `https://phantomjscloud.com/api/browser/v2/${key}/?request=${payload}`;
  const response = UrlFetchApp.fetch(apiUrl, { muteHttpExceptions: true });

  if (response.getResponseCode() !== 200) {
    throw new Error(`PhantomJSCloud API Error: HTTP ${response.getResponseCode()} - ${response.getContentText()}`);
  }

  const json = JSON.parse(response.getContentText());
  if (json.content && json.content.data) return json.content.data;
  throw new Error("PhantomJSCloudからのHTML取得に失敗しました。");
}

// =================================================================================
// ダブルクロス 3rd Edition
// =================================================================================
function getDataDX(sheetData, url, img, opt, additionalPalette) {
  const roiceData = createDxRoiceFromJson(sheetData);

  let comboPalette = "";
  const comboData = getComboDataFromDatabase(url);
  if (comboData) comboPalette = createComboPaletteFromData(comboData);

  let commands = opt[1] ? createDxChapaleFromJson(sheetData) : "";
  if (opt[1] && comboPalette) commands += (commands ? "\n" : "") + comboPalette;
  if (additionalPalette) commands += (commands ? "\n" : "") + additionalPalette;

  const memo = opt[0] ? createDxMemoFromJson(sheetData, roiceData) : "";

  const charJson = {
    kind: "character",
    data: {
      name: getDxName(sheetData),
      memo,
      initiative: toInt(sheetData.NP7),
      externalUrl: url,
      status: [
        { label: "HP", value: toInt(sheetData.NP5), max: toInt(sheetData.NP5) },
        { label: "侵蝕率", value: toInt(sheetData.NP6), max: 100 },
        { label: "侵蝕率D", value: 0, max: 3 },
        { label: "ロイス", value: roiceData.value, max: roiceData.max },
      ],
      params: [
        { label: "肉体", value: toZeroString(sheetData.NP1) },
        { label: "感覚", value: toZeroString(sheetData.NP2) },
        { label: "精神", value: toZeroString(sheetData.NP3) },
        { label: "社会", value: toZeroString(sheetData.NP4) },
        ...getDxSkillParamsFromJson(sheetData),
      ],
      commands,
    },
  };

  if (img) charJson.data.iconUrl = img;
  return charJson;
}

function getDxName(sheetData) {
  return firstText(sheetData.pc_name, sheetData.koma_name, sheetData.data_title, "(名前未設定)");
}

function createDxMemoFromJson(sheetData, roiceData) {
  const lines = [];
  lines.push(`コードネーム：${cleanText(sheetData.pc_codename)}`);
  lines.push(`ワークス：${cleanText(sheetData.works_name)}　カヴァー：${cleanText(sheetData.cover_name)}`);

  const syndrome = [cleanText(sheetData.class1_name), cleanText(sheetData.class2_name), cleanText(sheetData.class3_name)]
    .filter(Boolean)
    .join("/");
  if (syndrome) lines.push(`シンドローム：${syndrome}`);

  const ageSex = [cleanText(sheetData.age), cleanText(sheetData.sex)].filter(Boolean).join(" / ");
  if (ageSex) lines.push(`年齢/性別：${ageSex}`);

  if (cleanText(sheetData.pc_making_memo)) {
    lines.push("");
    lines.push(cleanText(sheetData.pc_making_memo));
  }

  lines.push("");
  lines.push(roiceData.memo);
  return lines.join("\n");
}

function getDxSkillParamsFromJson(sheetData) {
  const tokugi = arrayOrEmpty(sheetData.skill_tokugi);
  const namedSkills = getDxNamedSkillsFromJson(sheetData);
  const hasNamed = {};
  namedSkills.forEach((skill) => {
    hasNamed[skill.kind] = true;
  });

  const params = [
    { label: "白兵", value: toZeroString(tokugi[0]) },
    { label: "回避", value: toZeroString(tokugi[1]) },
    ...(hasNamed["運転"] ? [] : [{ label: "運転", value: toZeroString(tokugi[2]) }]),

    { label: "射撃", value: toZeroString(tokugi[3]) },
    { label: "知覚", value: toZeroString(tokugi[4]) },
    ...(hasNamed["芸術"] ? [] : [{ label: "芸術", value: toZeroString(tokugi[5]) }]),

    { label: "RC", value: toZeroString(tokugi[6]) },
    { label: "意志", value: toZeroString(tokugi[7]) },
    ...(hasNamed["知識"] ? [] : [{ label: "知識", value: toZeroString(tokugi[8]) }]),

    { label: "交渉", value: toZeroString(tokugi[9]) },
    { label: "調達", value: toZeroString(tokugi[10]) },
    ...(hasNamed["情報"] ? [] : [{ label: "情報", value: toZeroString(tokugi[11]) }]),
  ];

  namedSkills.forEach((skill) => {
    params.push({ label: skill.label, value: skill.value });
  });

  return dedupeParams(params);
}

function getDxNamedSkillsFromJson(sheetData) {
  const tokugi = arrayOrEmpty(sheetData.skill_tokugi);
  const memo = arrayOrEmpty(sheetData.skill_memo);
  const skillIds = Array.isArray(sheetData.V_skill_id)
    ? sheetData.V_skill_id
    : Array.isArray(sheetData.skill_id)
      ? sheetData.skill_id
      : [];

  const result = [];
  const baseNamedIndexes = {
    2: "運転",
    5: "芸術",
    8: "知識",
    11: "情報",
  };

  Object.keys(baseNamedIndexes).forEach((indexText) => {
    const i = Number(indexText);
    const kind = baseNamedIndexes[i];
    const name = cleanText(memo[i]);
    if (!name) return;

    result.push({
      kind,
      label: `${kind}:${name}`,
      value: toZeroString(tokugi[i]),
    });
  });

  const skillKindMap = {
    "1": "運転",
    "2": "芸術",
    "3": "知識",
    "4": "情報",
  };

  const baseSkillCount = 12;
  for (let i = baseSkillCount; i < tokugi.length; i++) {
    const kindId = cleanText(skillIds[i - baseSkillCount]);
    const kind = skillKindMap[kindId];
    const name = cleanText(memo[i]);
    if (!kind || !name) continue;

    result.push({
      kind,
      label: `${kind}:${name}`,
      value: toZeroString(tokugi[i]),
    });
  }

  return result;
}

function groupDxNamedSkillsByKind(sheetData) {
  const namedSkills = getDxNamedSkillsFromJson(sheetData);
  const grouped = {
    "運転": [],
    "芸術": [],
    "知識": [],
    "情報": [],
  };

  namedSkills.forEach((skill) => {
    if (!grouped[skill.kind]) return;
    grouped[skill.kind].push(skill);
  });

  return grouped;
}

function createDxChapaleFromJson(sheetData) {
  const namedSkills = groupDxNamedSkillsByKind(sheetData);

  const lines = [
    "ステータス 肉体:{肉体} 感覚:{感覚} 精神:{精神} 社会:{社会}",

    "({肉体}+{侵蝕率D})DX+{白兵} 肉体〈白兵〉",
    "({肉体}+{侵蝕率D})DX+{回避} 肉体〈回避〉",
    createDxBaseOrZeroLine("肉体", "運転", namedSkills),
    ...createDxNamedSkillLines("肉体", "運転", namedSkills),

    "({感覚}+{侵蝕率D})DX+{射撃} 感覚〈射撃〉",
    "({感覚}+{侵蝕率D})DX+{知覚} 感覚〈知覚〉",
    createDxBaseOrZeroLine("感覚", "芸術", namedSkills),
    ...createDxNamedSkillLines("感覚", "芸術", namedSkills),

    "({精神}+{侵蝕率D})DX+{RC} 精神〈RC〉",
    "({精神}+{侵蝕率D})DX+{意志} 精神〈意志〉",
    createDxBaseOrZeroLine("精神", "知識", namedSkills),
    ...createDxNamedSkillLines("精神", "知識", namedSkills),

    "({社会}+{侵蝕率D})DX+{交渉} 社会〈交渉〉",
    "({社会}+{侵蝕率D})DX+{調達} 社会〈調達〉",
    createDxBaseOrZeroLine("社会", "情報", namedSkills),
    ...createDxNamedSkillLines("社会", "情報", namedSkills),

    "1D リザレクト",
  ];

  return lines.join("\n");
}

function createDxBaseOrZeroLine(ability, kind, namedSkills) {
  const hasNamed = namedSkills[kind] && namedSkills[kind].length;
  const mod = hasNamed ? "0" : `{${kind}}`;
  return `({${ability}}+{侵蝕率D})DX+${mod} ${ability}〈${kind}〉`;
}

function createDxNamedSkillLines(ability, kind, namedSkills) {
  const list = namedSkills[kind] || [];
  return list.map((skill) => `({${ability}}+{侵蝕率D})DX+{${skill.label}} ${ability}〈${skill.label}〉`);
}

function createDxRoiceFromJson(sheetData) {
  const types = arrayOrEmpty(sheetData.roice_type);
  const names = arrayOrEmpty(sheetData.roice_name);
  const pos = arrayOrEmpty(sheetData.roice_pos);
  const neg = arrayOrEmpty(sheetData.roice_neg);
  const posIds = arrayOrEmpty(sheetData.roice_pos_id);
  const negIds = arrayOrEmpty(sheetData.roice_neg_id);
  const memos = arrayOrEmpty(sheetData.roice_memo);

  let roiceMemo = "😀 ロイス/😡 タイタス/💥 Dロイス/💕 Sロイス\n";
  let roiceCount = 0;
  let roiceMax = 7;

  names.forEach((nameRaw, index) => {
    const name = cleanText(nameRaw);
    if (!name) return;

    roiceCount++;

    let icon = "😀";
    const type = cleanText(types[index]);

    if (type === "1") {
      icon = "💥";
      roiceMax--;
    } else if (type === "2") {
      icon = "💕";
    }

    const posText = normalizeDxRoiceEmotion(pos[index], posIds[index]);
    const negText = normalizeDxRoiceEmotion(neg[index], negIds[index]);
    const memoText = cleanText(memos[index]);

    const memoMainSide = detectDxRoiceMainEmotionFromMemo(
      memoText,
      posText,
      negText,
    );

    const posChecked =
      memoMainSide === "pos"
        ? true
        : memoMainSide === "neg"
          ? false
          : isDxRoiceEmotionChecked(sheetData, "pos", index);

    const negChecked =
      memoMainSide === "neg"
        ? true
        : memoMainSide === "pos"
          ? false
          : isDxRoiceEmotionChecked(sheetData, "neg", index);

    const emotionText = formatDxRoiceEmotionText(
      posText,
      negText,
      posChecked,
      negChecked,
    );

    roiceMemo += `${index + 1}. ${icon}：${name}`;
    if (emotionText) roiceMemo += `　${emotionText}`;
    roiceMemo += "\n";
  });

  return {
    memo: roiceMemo.trim(),
    value: roiceCount,
    max: roiceMax,
  };
}

function normalizeDxRoiceEmotion(value, id) {
  const text = cleanText(value);
  const emotionId = cleanText(id);

  if (!text) return "";
  if (emotionId === "0") return "";
  if (text === "←自由選択") return "";
  if (text.indexOf("自由選択") >= 0) return "";

  return text;
}

function formatDxRoiceEmotionText(posText, negText, posChecked, negChecked) {
  const pos = cleanText(posText);
  const neg = cleanText(negText);

  if (!pos && !neg) return "";

  let posOut = pos;
  let negOut = neg;

  if (pos && posChecked) posOut = `◯${pos}`;
  if (neg && negChecked) negOut = `◯${neg}`;

  if (posOut && negOut) return `${posOut}/${negOut}`;
  return posOut || negOut;
}

function detectDxRoiceMainEmotionFromMemo(memoText, posText, negText) {
  const memo = cleanText(memoText);
  const pos = cleanText(posText);
  const neg = cleanText(negText);

  if (!memo) return "";

  const normalizedMemo = memo
    .replace(/[〇○]/g, "◯")
    .replace(/[：]/g, ":")
    .replace(/\s+/g, "");

  const posHit = pos ? isDxRoiceEmotionMainInMemo(normalizedMemo, pos) : false;
  const negHit = neg ? isDxRoiceEmotionMainInMemo(normalizedMemo, neg) : false;

  if (posHit && !negHit) return "pos";
  if (negHit && !posHit) return "neg";

  return "";
}

function isDxRoiceEmotionMainInMemo(normalizedMemo, emotion) {
  const e = escapeRegExpForDxRoice(cleanText(emotion));
  if (!e) return false;

  const patterns = [
    new RegExp(`表[:：]?${e}`),
    new RegExp(`${e}が表`),
    new RegExp(`${e}を表`),
    new RegExp(`${e}表`),
    new RegExp(`${e}が強い`),
    new RegExp(`${e}のほうが強い`),
    new RegExp(`${e}の方が強い`),
    new RegExp(`${e}寄り`),
    new RegExp(`◯${e}`),
  ];

  return patterns.some((re) => re.test(normalizedMemo));
}

function escapeRegExpForDxRoice(value) {
  return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function isDxRoiceEmotionChecked(sheetData, side, index) {
  const keys =
    side === "pos"
      ? [
          "roice_pos_input",
          "roice_pos_checked",
          "roice_pos_main",
          "roice_pos_omote",
        ]
      : [
          "roice_neg_input",
          "roice_neg_checked",
          "roice_neg_main",
          "roice_neg_omote",
        ];

  for (let i = 0; i < keys.length; i++) {
    if (isDxRoiceCheckValueAt(sheetData && sheetData[keys[i]], index)) {
      return true;
    }
  }

  return false;
}

function isDxRoiceCheckValueAt(value, index) {
  if (value === null || value === undefined) return false;

  if (Array.isArray(value)) {
    return isTruthyCheckValue(value[index]);
  }

  if (typeof value === "object") {
    return (
      isTruthyCheckValue(value[index]) ||
      isTruthyCheckValue(value[String(index)])
    );
  }

  const text = cleanText(value);
  if (!text) return false;

  if (isTruthyCheckValue(text)) return true;

  const tokens = text
    .split(/[,\s|/]+/)
    .map((x) => x.trim())
    .filter(Boolean);

  return tokens.indexOf(String(index)) >= 0;
}

function isTruthyCheckValue(value) {
  const text = cleanText(value).toLowerCase();

  return (
    text === "1" ||
    text === "true" ||
    text === "checked" ||
    text === "on"
  );
}

function getEffectFromDxJson(sheetData) {
  const names = arrayOrEmpty(sheetData.effect_name).map(cleanText).filter(Boolean);
  const levels = arrayOrEmpty(sheetData.effect_lv).map(cleanText).filter((v) => v !== "");
  return [names, levels];
}

// 旧UIから呼ばれている可能性への互換。JSON化後はgetEffectFromDxJsonを使う。
function getEffect(responseText) {
  const names = Parser.data(responseText).from('id="effect_name[]"').to('value="').to('"').iterate();
  const levels = Parser.data(responseText).from('id="effect_lv[]"').to('value="').to('"').iterate();
  return [names, levels];
}

// =================================================================================
// 永い後日談のネクロニカ
// =================================================================================
function getDataNC(sheetData, url, img, opt, additionalPalette) {
  const parts = getNcPartsFromJson(sheetData);
  const bui = [
    ["【マニューバ名】 《タイミング / コスト / 射程》"],
    ["🟩"],
    ["👧頭"],
    ["💪腕"],
    ["🧍胴"],
    ["🦵脚"],
  ];

  parts.forEach((part) => pushNcPartToGroups(part, bui));

  const commandPalette = bui
    .filter((group) => group.length > 1 || group[0] === "【マニューバ名】 《タイミング / コスト / 射程》")
    .map((group) => group.join("\n"))
    .join("\n");

  const initiative = toInt(firstText(sheetData.Act_Total, sheetData.act_total));
  const status = createNcStatus(sheetData, bui);
  const memo = opt[0] ? createNcMemo(sheetData) : "";

  let commands = opt[1] ? commandPalette + createNcGenericPalette(initiative) : "";
  if (additionalPalette) commands += (commands ? "\n" : "") + additionalPalette;

  const charJson = {
    kind: "character",
    data: {
      name: getNcName(sheetData),
      memo,
      initiative,
      externalUrl: url,
      status,
      commands,
    },
  };

  if (img) charJson.data.iconUrl = img;
  return charJson;
}

function getNcName(sheetData) {
  return firstText(sheetData.pc_name, sheetData.koma_name, sheetData.data_title, "(名前未設定)");
}

function getNcPartsFromJson(sheetData) {
  const names = arrayOrEmpty(sheetData.Power_name);
  const positions = Array.isArray(sheetData.V_Power_hantei) ? sheetData.V_Power_hantei : arrayOrEmpty(sheetData.Power_hantei);
  const timings = Array.isArray(sheetData.V_Power_timing) ? sheetData.V_Power_timing : arrayOrEmpty(sheetData.Power_timing);
  const costs = arrayOrEmpty(sheetData.Power_cost);
  const ranges = arrayOrEmpty(sheetData.Power_range);
  const memos = arrayOrEmpty(sheetData.Power_memo);

  const parts = [];
  for (let i = 0; i < names.length; i++) {
    const name = cleanText(names[i]);
    if (!name || name.indexOf("Power_id") >= 0) continue;

    parts.push({
      name,
      position: cleanText(positions[i]),
      timing: convertNcTiming(cleanText(timings[i])),
      cost: cleanText(costs[i]),
      range: cleanText(ranges[i]),
      memo: cleanText(memos[i]),
    });
  }
  return parts;
}

function pushNcPartToGroups(part, bui) {
  const memoText = part.memo ? `\\n${part.memo.replace(/[\r\n]+/g, "\\n")}` : "";
  const maneuverText = `【${part.name}】《${part.timing}/${part.cost}/${part.range}》${memoText}`;

  switch (part.position) {
    case "1":
    case "2":
    case "3":
      bui[1].push(`🟩${maneuverText}`);
      break;
    case "4":
      bui[2].push(maneuverText);
      break;
    case "5":
      bui[3].push(maneuverText);
      break;
    case "6":
      bui[4].push(maneuverText);
      break;
    case "7":
      bui[5].push(maneuverText);
      break;
  }
}

function convertNcTiming(x) {
  switch (String(x)) {
    case "0": return "オート";
    case "1": return "アクション";
    case "2": return "ジャッジ";
    case "3": return "ダメージ";
    case "4": return "ラピッド";
    default: return cleanText(x);
  }
}

function createNcStatus(sheetData, bui) {
  const status = [
    { label: "頭", value: Math.max(0, bui[2].length - 1), max: Math.max(0, bui[2].length - 1) },
    { label: "腕", value: Math.max(0, bui[3].length - 1), max: Math.max(0, bui[3].length - 1) },
    { label: "胴", value: Math.max(0, bui[4].length - 1), max: Math.max(0, bui[4].length - 1) },
    { label: "脚", value: Math.max(0, bui[5].length - 1), max: Math.max(0, bui[5].length - 1) },
  ];

  const names = arrayOrEmpty(sheetData.roice_name);
  const positions = arrayOrEmpty(sheetData.roice_pos);
  const damages = arrayOrEmpty(sheetData.roice_damage);

  for (let i = 0; i < names.length; i++) {
    const name = cleanText(names[i]);
    if (!name) continue;
    status.push({
      label: `${name}(${cleanText(positions[i])})`,
      value: toInt(damages[i]),
      max: 4,
    });
  }

  return status;
}

function createNcMemo(sheetData) {
  const lines = [];
  lines.push("基礎データ:");
  lines.push(`暗示：${cleanText(sheetData.pc_carma)}　享年：${cleanText(sheetData.age)}`);
  lines.push(`ポジション：${cleanText(sheetData.Position_Name)}`);
  lines.push(`クラス：${cleanText(sheetData.MCLS_Name)}/${cleanText(sheetData.SCLS_Name)}`);
  lines.push(`初期配置：${cleanText(sheetData.sex)}`);

  const kakera = arrayOrEmpty(sheetData.kakera_name).map(cleanText).filter(Boolean);
  if (kakera.length) {
    lines.push("[記憶のカケラ]");
    lines.push(kakera.join("、"));
  }

  const memo = cleanText(sheetData.pc_making_memo || sheetData.memo);
  if (memo) {
    lines.push("");
    lines.push(memo);
  }
  return lines.join("\n");
}

function createNcGenericPalette(initiative) {
  return [
    "◆汎用",
    "nm 未練表",
    "nmn 中立者への未練表",
    "nme 敵への未練表",
    "NC+1 対話判定：",
    "NC 対話判定：",
    "NC-1 対話判定：",
    "NC+2 狂気判定",
    "NC+1 狂気判定",
    "NC 狂気判定",
    "NC-1 狂気判定",
    "NC-2 狂気判定",
    "NC+2 行動判定",
    "NC+1 行動判定",
    "NC 行動判定",
    "NC-1 行動判定",
    "NC-2 行動判定",
    "NA+2 攻撃判定",
    "NA+1 攻撃判定",
    "NA 攻撃判定",
    "NA-1 行動判定",
    "NA-2 行動判定",
    "◆行動値操作",
    ":initiative-1",
    ":initiative-2",
    ":initiative-3",
    `:initiative=${initiative}`,
  ].join("\n");
}

// =================================================================================
// サタスペ
// =================================================================================
function getDataSata(sheetData, url, img, opt, additionalPalette) {
  const base = sheetData.base || {};
  const cond = sheetData.cond || {};

  let commands = opt[1] ? chapareSataFromJson(sheetData) : "";
  if (additionalPalette) commands += (commands ? "\n" : "") + additionalPalette;

  const life = toInt(base.abl && base.abl.life && base.abl.life.value);
  const bodyMax = 10;
  const mentalMax = 10;
  const walletMax = Math.max(0, life);

  const charJson = {
    kind: "character",
    data: {
      name: firstText(base.name, base.nameKana, "(名前未設定)"),
      memo: opt[0] ? createSatasupeMemoFromJson(sheetData) : "",
      initiative: toInt(base.power && base.power.initiative),
      externalUrl: url,
      status: [
        { label: "肉体点", value: bodyMax - toInt(cond.body && cond.body.value), max: bodyMax },
        { label: "精神点", value: mentalMax - toInt(cond.mental && cond.mental.value), max: mentalMax },
        { label: "サイフ", value: walletMax - toInt(cond.wallet && cond.wallet.value), max: walletMax },
        { label: "性業値", value: toInt(base.emotion), max: 13 },
      ],
      params: [
        { label: "犯罪", value: toZeroString(base.abl && base.abl.crime && base.abl.crime.value) },
        { label: "生活", value: toZeroString(base.abl && base.abl.life && base.abl.life.value) },
        { label: "恋愛", value: toZeroString(base.abl && base.abl.love && base.abl.love.value) },
        { label: "教養", value: toZeroString(base.abl && base.abl.culture && base.abl.culture.value) },
        { label: "戦闘", value: toZeroString(base.abl && base.abl.combat && base.abl.combat.value) },
        { label: "肉体", value: toZeroString(base.gift && base.gift.body && base.gift.body.value) },
        { label: "精神", value: toZeroString(base.gift && base.gift.mind && base.gift.mind.value) },
        { label: "反応力", value: toZeroString(base.power && base.power.initiative) },
        { label: "攻撃力", value: toZeroString(base.power && base.power.attack) },
        { label: "破壊力", value: toZeroString(base.power && base.power.destroy) },
      ],
      commands,
    },
  };

  if (img) charJson.data.iconUrl = img;
  return charJson;
}


function getSatasupeItemLimits(sheetData) {
  const base = sheetData.base || {};
  const abl = base.abl || {};
  const gift = base.gift || {};

  const handMax =
    toInt(abl.crime && abl.crime.value) +
    toInt(gift.body && gift.body.value);
  const ajitoMax = 10;
  const vehicleMax = arrayOrEmpty(sheetData.vehicles).reduce((max, vehicle) => {
    return Math.max(max, toInt(vehicle && vehicle.burden));
  }, 0);

  return { handMax, ajitoMax, vehicleMax };
}

function getSatasupeItemSections(sheetData) {
  const out = { hand: [], ajito: [], vehicle: [] };

  const pushItem = (name, opts) => {
    const nm = cleanText(name);
    if (!nm) return;
    if (["武器なし", "乗り物なし", "乗物なし"].indexOf(nm) >= 0) return;

    const place = cleanText(opts && opts.place);
    const use = cleanText(opts && opts.use);
    const where = place || use;
    const isAjito = where.indexOf("アジト") >= 0;
    const isVehicle = where.indexOf("乗物") >= 0 || where.indexOf("乗り物") >= 0;

    let line = nm;
    if (where && !isAjito && !isVehicle && where !== "装備" && where !== "所持") {
      line += `（${where}に）`;
    }

    if (isAjito) out.ajito.push(line);
    else if (isVehicle) out.vehicle.push(line);
    else out.hand.push(line);
  };

  arrayOrEmpty(sheetData.outfits).forEach((item) => {
    pushItem(item && item.name, { place: item && item.place, use: item && item.use });
  });
  arrayOrEmpty(sheetData.weapons).forEach((item) => {
    pushItem(item && item.name, { place: item && item.place, use: item && item.use });
  });
  arrayOrEmpty(sheetData.vehicles).forEach((item) => {
    pushItem(item && item.name, { place: item && item.place, use: item && item.use });
  });

  return out;
}

function createSatasupeMemoFromJson(sheetData) {
  const base = sheetData.base || {};
  const abl = base.abl || {};
  const gift = base.gift || {};
  const power = base.power || {};
  const karmaList = arrayOrEmpty(sheetData.karma);

  const talentNames = karmaList.map((k) => cleanText(k && k.talent && k.talent.name)).filter(Boolean);
  const priceNames = karmaList.map((k) => cleanText(k && k.price && k.price.name)).filter(Boolean);

  const lines = [];
  lines.push("───");
  lines.push(`【PL名】${cleanText(base.player) || "○○"}`);
  lines.push(`【PC名】${cleanText(base.name)}`);
  lines.push(`年齢：${cleanText(base.age)}　性別：${cleanText(base.sex)}`);
  if (cleanText(base.favorites)) lines.push(`好み：${cleanText(base.favorites)}`);
  lines.push(`【犯罪】${cleanText(abl.crime && abl.crime.value)}【生活】${cleanText(abl.life && abl.life.value)}【恋愛】${cleanText(abl.love && abl.love.value)}【教養】${cleanText(abl.culture && abl.culture.value)}【戦闘】${cleanText(abl.combat && abl.combat.value)}`);
  lines.push(`【肉体】${cleanText(gift.body && gift.body.value)}【精神】${cleanText(gift.mind && gift.mind.value)}`);
  lines.push(`【性業値】${cleanText(base.emotion)}`);
  lines.push(`【反応力】${cleanText(power.initiative)}【攻撃力】${cleanText(power.attack)}【破壊力】${cleanText(power.destroy)}`);

  const hobbies = createSatasupeHobbyList(sheetData);
  if (hobbies.length) lines.push(`趣味：${hobbies.join("、")}`);
  if (talentNames.length) lines.push(`異能：${talentNames.join("")}`);
  if (priceNames.length) lines.push(`代償：${priceNames.join("")}`);

  const memo = cleanText(base.memo);
  if (memo) {
    lines.push("");
    lines.push(memo);
  }
  lines.push("───");
  return lines.join("\n");
}

function createSatasupeHobbyList(sheetData) {
  const learned = arrayOrEmpty(sheetData.learned);

  // 必要に応じて増やせる。未登録IDはID表示で落とさない。
  const hobbyNameMap = {
    "hobby.4_6": "旅行",
    "hobby.1_5": "マニア",
    "hobby.1_2": "アブノーマル",
    "hobby.2_6": "美術",
  };

  return learned
    .map((x) => cleanText(x && x.id))
    .filter(Boolean)
    .map((id) => hobbyNameMap[id] || id);
}

function chapareSataFromJson(sheetData) {
  const parts = [
    createSatasupeBasicPalette(),
    createSatasupeGenericPalette(),
    createSatasupeWeaponPalette(sheetData),
    "＠判定\n",
    createSatasupeKarmaPalette(sheetData),
    createSatasupeTablePalette(),
  ].filter(Boolean);

  return parts.join("\n");
}

function createSatasupeBasicPalette() {
  return [
    "＠基本",
    "SR({性業値}) 性業値判定",
    "({犯罪})R>=X[,1,13] 犯罪判定",
    "({生活})R>=X[,1,13] 生活判定",
    "({恋愛})R>=X[,1,13] 恋愛判定",
    "({教養})R>=X[,1,13] 教養判定",
    "({戦闘})R>=X[,1,13] 戦闘判定",
    "({肉体})R>=X[,1,13] 肉体判定",
    "({精神})R>=X[,1,13] 精神判定",
  ].join("\n");
}

function createSatasupeGenericPalette() {
  return [
    "＠汎用",
    "({肉体})R>=X[,1,13] セーブ判定",
    "({肉体})R>=X[1,2,13] 跳ぶ",
    "({教養})R>=X[4,1,13] リンク判定",
    "CultureIET イベント表",
    "CultureIHT ハプニング表",
    "({肉体})R>=7[1,1,13] BT(酒)",
  ].join("\n");
}

function createSatasupeWeaponPalette(sheetData) {
  const weapons = arrayOrEmpty(sheetData.weapons).filter((w) => w && cleanText(w.name));
  const lines = ["＠武器", "({攻撃力})R>=6[,1,13] 武器なし 破壊力:0 ※成功度加算不可"];

  weapons.forEach((w) => {
    const name = cleanText(w.name);
    const aim = cleanText(w.aim) || "X";
    const damage = cleanText(w.damage) || "?";
    lines.push(`({攻撃力})R>=${aim}[,1,13] ${name}　破壊力:${damage}`);
  });

  lines.push("({攻撃力})R>=X[,1,13] 攻撃力判定");
  return lines.join("\n");
}

function createSatasupeKarmaPalette(sheetData) {
  const karmaList = arrayOrEmpty(sheetData.karma);
  const lines = [];

  const pushEntry = (entry) => {
    if (!entry || !entry.name) return;

    const name = cleanText(entry.name);
    const use = cleanText(entry.use) || "なし";
    const target = cleanText(entry.target) || "なし";
    const judge = cleanText(entry.judge) || "なし";
    const effect = cleanText(entry.effect);
    const meta = [use, target, judge].join("・");

    if (effect) {
      lines.push(`${name}${meta}\\n${effect}`);
    } else {
      lines.push(`${name}${meta}`);
    }
  };

  karmaList.forEach((k) => {
    if (!k) return;
    pushEntry(k.talent);
    pushEntry(k.price);
  });

  return lines.length ? "＠異能/代償\n" + lines.join("\n") : "";
}

function createSatasupeTablePalette() {
  return [
    "各種表",
    "TAGT 情報タグ決定表",
    "FumbleT 命中判定ファンブル表",
    "FatalT 14番表",
    "FatalT 致命傷表",
    "FatalVT 乗物致命傷表",
    "RomanceFT ロマンスファンブル表",
    "AccidentT ケチャップアクシデント表",
    "GeneralAT 汎用アクシデント表",
    "AfterT その後表",
    "KusaiMT 臭い飯表",
    "EnterT 登場表",
    "BudTT バッドトリップ表",
    "GetgT ガラクタ表",
    "GetzT 実用品表",
    "GetnT 値打ち物表",
    "GetkT 奇天烈表",
    "CrimeIET 犯罪イベント表",
    "LifeIET 生活イベント表",
    "LoveIET 恋愛イベント表",
    "CultureIET 教養イベント表",
    "CombatIET 戦闘イベント表",
    "CrimeIHT 犯罪ハプニング表",
    "LifeIHT 生活ハプニング表",
    "LoveIHT 恋愛ハプニング表",
    "CultureIHT 教養ハプニング表",
    "CombatIHT 戦闘ハプニング表",
    "MinamiRET ミナミ遭遇表",
    "ChinatownRET 中華街遭遇表",
    "WarshipLandRET 軍艦島遭遇表",
    "CivicCenterRET 官庁街遭遇表",
    "DowntownRET 十三遭遇表",
    "ShaokinRET 沙京遭遇表",
    "LoveLoveRET らぶらぶ遭遇表",
    "AjitoRET アジト遭遇表",
    "JigokuSpaRET 地獄湯遭遇表",
    "JailHouseRET JAIL HOUSE遭遇表",
    "TreatmentIT 治療イベント表",
    "CollegeIT 大学イベント表",
  ].join("\n");
}

// =================================================================================
// DX3コンボジェネレーター連携
// =================================================================================
function getComboDataFromDatabase(id) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("ComboData");
  if (!sheet) {
    Logger.log("Sheet 'ComboData' not found.");
    return null;
  }

  let row = -1;
  if (typeof findRowById === "function") {
    row = findRowById(sheet, id);
  } else {
    row = findRowByIdFallback(sheet, id);
  }

  if (row > 0) {
    const dataString = sheet.getRange(row, 2).getValue();
    try {
      return JSON.parse(dataString);
    } catch (e) {
      Logger.log(`Failed to parse JSON for ID ${id}: ${e}`);
      return null;
    }
  }
  return null;
}

function findRowByIdFallback(sheet, id) {
  const values = sheet.getRange(1, 1, sheet.getLastRow(), 1).getValues();
  for (let i = 0; i < values.length; i++) {
    if (String(values[i][0]) === String(id)) return i + 1;
  }
  return -1;
}

function createComboPaletteFromData(comboData) {
  if (!comboData || !Array.isArray(comboData.combos)) return "";

  const allEffects = [
    ...(comboData.effects || []),
    ...(comboData.easyEffects || []),
  ];
  const items = Array.isArray(comboData.items) ? comboData.items : [];

  const normalizeSkillName = (v) => {
    const s = String(v || "").replace(/[〈〉【】]/g, "").replace(/\s+/g, "").trim();
    if (!s || s === "-" || s === "シンドローム") return "-";
    if (s.indexOf("白兵") >= 0) return s.indexOf(":") >= 0 ? s : "白兵";
    if (s.indexOf("回避") >= 0) return s.indexOf(":") >= 0 ? s : "回避";
    if (s.indexOf("運転") >= 0) return s;
    if (s.indexOf("射撃") >= 0) return s.indexOf(":") >= 0 ? s : "射撃";
    if (s.indexOf("知覚") >= 0) return s.indexOf(":") >= 0 ? s : "知覚";
    if (s.indexOf("芸術") >= 0) return s;
    if (s.indexOf("RC") >= 0) return "RC";
    if (s.indexOf("意志") >= 0) return "意志";
    if (s.indexOf("知識") >= 0) return s;
    if (s.indexOf("交渉") >= 0) return "交渉";
    if (s.indexOf("調達") >= 0) return "調達";
    if (s.indexOf("情報") >= 0) return s;
    return s;
  };

  const getAbilityBySkill = (skill) => {
    const s = String(skill || "").replace(/[〈〉【】]/g, "").replace(/\s+/g, "").trim();
    if (s.indexOf("白兵") === 0 || s.indexOf("回避") === 0 || s.indexOf("運転") === 0) return "肉体";
    if (s.indexOf("射撃") === 0 || s.indexOf("知覚") === 0 || s.indexOf("芸術") === 0) return "感覚";
    if (s.indexOf("RC") === 0 || s.indexOf("意志") === 0 || s.indexOf("知識") === 0) return "精神";
    if (s.indexOf("交渉") === 0 || s.indexOf("調達") === 0 || s.indexOf("情報") === 0) return "社会";
    return "肉体";
  };

  const comboName = (combo) => String((combo && combo.name) || "").trim() || "コンボ名入れて！！！！";
  const toCommandPart = (v) => String(v || "").replace(/\r?\n/g, "\\n").trim();
  const joinCommand = (parts) => parts.map(toCommandPart).filter(Boolean).join("\\n");
  const pickVal = (v, defVal) => {
    if (v === null || v === undefined || String(v).trim() === "") return defVal;
    return String(v).trim();
  };
  const evaluateNumber = (v) => {
    const n = Number(v || 0);
    return Number.isFinite(n) ? n : 0;
  };
  const getSources = (combo) => {
    const effectNames = combo && Array.isArray(combo.effectNames) ? combo.effectNames : [];
    const itemNames = combo && Array.isArray(combo.itemNames) ? combo.itemNames : [];
    const effects = effectNames.map((x) => {
      const name = typeof x === "string" ? x : String((x && x.name) || "");
      const found = allEffects.find((e) => e && e.name === name);
      return found ? { ...found, sourceType: "effect" } : null;
    }).filter(Boolean);
    const selectedItems = itemNames.map((x) => {
      const name = typeof x === "string" ? x : String((x && x.name) || "");
      const found = items.find((i) => i && i.name === name);
      return found ? { ...found, sourceType: "item" } : null;
    }).filter(Boolean);
    return [...effects, ...selectedItems];
  };
  const calcCrit = (sources, comboLevelBonus) => {
    let correctionTotal = 0;
    let minLimit = 10;
    sources.forEach((source) => {
      if (!source || !source.values || !source.values.crit) return;
      const crit = source.values.crit;
      const lv = source.level !== undefined ? evaluateNumber(source.level) + comboLevelBonus : 0;
      let base = evaluateNumber(crit.base);
      let per = evaluateNumber(crit.perLevel);
      const min = evaluateNumber(crit.min) || 10;
      if (base >= 2 || per > 0) {
        base = base - 10;
        if (per > 0) per = -Math.abs(per);
      }
      const correction = base + lv * per;
      if (correction !== 0) {
        correctionTotal += correction;
        if (correction < 0) minLimit = Math.min(minLimit, min);
      }
    });
    return Math.max(10 + correctionTotal, minLimit);
  };
  const calcFixed = (sources, key, comboLevelBonus) => {
    return sources.reduce((acc, source) => {
      if (!source || !source.values || !source.values[key]) return acc;
      const lv = source.level !== undefined ? evaluateNumber(source.level) + comboLevelBonus : 0;
      return acc + evaluateNumber(source.values[key].base) + lv * evaluateNumber(source.values[key].perLevel);
    }, 0);
  };
  const getPriorityValue = (sources, prop, defVal) => {
    const first = sources.find((s) => s && s[prop] && String(s[prop]).trim() && String(s[prop]).trim() !== "-");
    return first ? String(first[prop]).trim() : defVal;
  };

  const commands = ["//▼コンボデータ"];
  comboData.combos.forEach((combo) => {
    if (!combo) return;
    const sources = getSources(combo);
    const comboLevelBonus = evaluateNumber(combo.comboLevelBonus);
    const compositionText = sources
      .filter((s) => s.sourceType === "effect")
      .map((e) => `《${e.name}》Lv${(evaluateNumber(e.level) || 1) + comboLevelBonus}`)
      .join("+");
    const flavorText = combo.flavor ? `『${combo.flavor}』` : "";
    const effectDescription = combo.effectDescriptionMode === "manual"
      ? String(combo.manualEffectDescription || "").trim()
      : sources.map((e) => String((e && (e.effect || e.notes)) || "").trim()).filter(Boolean).join("\n");
    const main = sources.find((s) => ["メジャー", "リアクション", "メジャー／リア"].indexOf(String(s.timing || "").trim()) >= 0) || sources[0] || {};
    const skill = normalizeSkillName((combo.baseAbility && combo.baseAbility.skill) || main.skill || "白兵");
    const skillForFormula = skill === "-" ? "白兵" : skill;
    const ability = (combo.baseAbility && combo.baseAbility.statOverride) || getAbilityBySkill(skillForFormula);
    const totalDice = calcFixed(sources.filter((s) => s.sourceType === "effect"), "dice", comboLevelBonus);
    const totalAchieve = calcFixed(sources.filter((s) => s.sourceType === "effect"), "achieve", comboLevelBonus);
    const totalAtk = calcFixed(sources, "attack", comboLevelBonus);
    const finalCrit = calcCrit(sources, comboLevelBonus);

    let diceFormula = `({${ability}}+{侵蝕率D}${totalDice >= 0 ? "+" : ""}${totalDice})DX${finalCrit}+{${skillForFormula}}`;
    if (totalAchieve !== 0) diceFormula += `${totalAchieve >= 0 ? "+" : ""}${totalAchieve}`;
    diceFormula += ` ◆${comboName(combo)}`;

    const details = [
      `侵蝕値:${pickVal(combo.totalCost || combo.cost, "0")}`,
      `タイミング:${pickVal(combo.timing || getPriorityValue(sources, "timing", "-"), "-")}`,
      `技能:${skillForFormula}`,
      `難易度:${pickVal(main.difficulty, "自動")}`,
      `対象:${pickVal(combo.target || getPriorityValue(sources, "target", "-"), "-")}`,
      `射程:${pickVal(combo.range || getPriorityValue(sources, "range", "-"), "-")}`,
      `攻撃力:${totalAtk}`,
      `達成値:${totalAchieve}`,
      `C値:${finalCrit}`,
    ].join("　");

    const declarationCommand = joinCommand([`◆${comboName(combo)}`, compositionText, flavorText, details, effectDescription]);
    if (declarationCommand) commands.push(declarationCommand);
    if (diceFormula) commands.push(diceFormula);
    commands.push("");
  });

  return commands.join("\n").trim();
}
