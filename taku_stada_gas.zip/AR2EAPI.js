// ===== AR2E API =====
const SHEET_NAME_AR2E = "AR2E_enemies";
const TOOL_NAME_AR2E = "ar2e";
const AR2E_HEADERS = [
  "ID",
  "author",
  "name",
  "class_type",
  "is_public",
  "memo",
  "data",
  "icon_url",
  "time",
];

function handleAR2EGet(action, e) {
  if (action === "listAR2EEnemies") {
    return listAR2EEnemies_(e);
  }
  if (action === "deleteAR2EEnemy") {
    return deleteAR2EEnemy_(e);
  }
  return {
    status: "error",
    message: `ar2e用の不正なactionです: ${action}`,
  };
}

function handleAR2EPost(payload) {
  const action = String((payload && payload.action) || "").trim();
  if (action === "saveAR2EEnemy") {
    return saveAR2EEnemy_(payload);
  }
  return {
    status: "error",
    message: `ar2e用の不正なactionです: ${action}`,
  };
}

function getAR2ESheet_() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = spreadsheet.getSheetByName(SHEET_NAME_AR2E);
  if (!sheet) sheet = spreadsheet.insertSheet(SHEET_NAME_AR2E);
  ensureAR2EHeaders_(sheet);
  return sheet;
}

function ensureAR2EHeaders_(sheet) {
  if (sheet.getMaxColumns() < AR2E_HEADERS.length) {
    sheet.insertColumnsAfter(
      sheet.getMaxColumns(),
      AR2E_HEADERS.length - sheet.getMaxColumns(),
    );
  }
  const row =
    sheet.getLastRow() >= 1
      ? sheet.getRange(1, 1, 1, AR2E_HEADERS.length).getValues()[0]
      : [];
  const hasHeader = AR2E_HEADERS.every(
    (name, idx) => String(row[idx] || "") === name,
  );
  if (!hasHeader) {
    sheet.getRange(1, 1, 1, AR2E_HEADERS.length).setValues([AR2E_HEADERS]);
  }
}

function getAR2EHeaderMap_(sheet) {
  const row =
    sheet.getRange(1, 1, 1, AR2E_HEADERS.length).getValues()[0] || [];
  const map = {};
  AR2E_HEADERS.forEach((name, idx) => {
    const actual = String(row[idx] || name);
    map[actual] = idx;
    if (actual !== name && map[name] == null) map[name] = idx;
  });
  return map;
}

function parseBoolAR2E_(v) {
  if (typeof v === "boolean") return v;
  const s = String(v || "")
    .trim()
    .toLowerCase();
  return s === "true" || s === "1" || s === "yes" || s === "on" || s === "公開";
}

function safeJsonAR2E_(text, fallback) {
  try {
    return JSON.parse(text);
  } catch (_e) {
    return fallback;
  }
}

function nowAR2ETimeText_() {
  const tz = Session.getScriptTimeZone() || "Asia/Tokyo";
  return Utilities.formatDate(new Date(), tz, "yyyy/MM/dd HH:mm:ss");
}

function isSequentialAR2EId_(value) {
  const s = String(value || "").trim();
  if (!/^\d+$/.test(s)) return false;
  const n = Number(s);
  return Number.isFinite(n) && n > 0 && n < 1000000000000;
}

function getNextAR2ESequentialId_(sheet, map) {
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return "1";
  const idCol = (map.ID != null ? map.ID : 0) + 1;
  const ids = sheet.getRange(2, idCol, lastRow - 1, 1).getValues();
  let maxId = 0;
  for (let i = 0; i < ids.length; i += 1) {
    const raw = ids[i][0];
    if (!isSequentialAR2EId_(raw)) continue;
    const n = Number(raw);
    if (n > maxId) maxId = n;
  }
  return String(maxId + 1);
}

function normalizeAR2EEnemy_(enemy) {
  const src = enemy && typeof enemy === "object" ? enemy : {};
  const now = nowAR2ETimeText_();
  const classTypeRaw = String(src.class_type || "general").trim();
  const classType = classTypeRaw === "mob" ? "mob" : "general";
  return {
    ID: String(src.ID || "").trim(),
    author: String(src.author || "").trim(),
    name: String(src.name || "").trim(),
    class_type: classType,
    is_public: !!src.is_public,
    memo: String(src.memo || ""),
    data:
      src.data && typeof src.data === "object"
        ? src.data
        : { sheet: {} },
    icon_url: String(src.icon_url || "").trim(),
    time: String(src.time || "").trim() || now,
  };
}

function ar2eEnemyToRow_(enemy) {
  return [
    enemy.ID,
    enemy.author,
    enemy.name,
    enemy.class_type,
    enemy.is_public ? "true" : "false",
    enemy.memo,
    JSON.stringify(enemy.data || {}),
    enemy.icon_url,
    enemy.time,
  ];
}

function rowToAR2EEnemy_(row, map) {
  const pick = (name) => row[map[name] != null ? map[name] : -1];
  const classTypeRaw = String(pick("class_type") || "").trim();
  return {
    ID: String(pick("ID") || "").trim(),
    author: String(pick("author") || "").trim(),
    name: String(pick("name") || "").trim(),
    class_type: classTypeRaw === "mob" ? "mob" : "general",
    is_public: parseBoolAR2E_(pick("is_public")),
    memo: String(pick("memo") || ""),
    data: safeJsonAR2E_(String(pick("data") || "{}"), { sheet: {} }),
    icon_url: String(pick("icon_url") || "").trim(),
    time: String(pick("time") || "").trim(),
  };
}

function listAR2EEnemies_(e) {
  const author = String((e && e.parameter && e.parameter.author) || "").trim();
  const params = (e && e.parameter) || {};
  const isAdminMode =
    String(params.admin || params.adminCode || "").trim() === "9800" &&
    (String(params.allAuthors || "").trim() === "1" ||
      String(params.includePrivate || "").trim() === "1");
  const sheet = getAR2ESheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { status: "success", data: [] };

  const map = getAR2EHeaderMap_(sheet);
  const rows = sheet
    .getRange(2, 1, lastRow - 1, AR2E_HEADERS.length)
    .getValues()
    .map((row) => rowToAR2EEnemy_(row, map))
    .filter((enemy) => {
      if (!enemy.ID) return false;
      if (isAdminMode) return true;
      if (enemy.is_public) return true;
      return author && enemy.author === author;
    })
    .sort((a, b) => String(b.time || "").localeCompare(String(a.time || "")));

  return { status: "success", data: rows };
}

function saveAR2EEnemy_(payload) {
  const enemy = normalizeAR2EEnemy_(payload && payload.enemy);
  enemy.time = nowAR2ETimeText_();

  const sheet = getAR2ESheet_();
  const map = getAR2EHeaderMap_(sheet);
  if (!isSequentialAR2EId_(enemy.ID)) {
    enemy.ID = getNextAR2ESequentialId_(sheet, map);
  }
  const idCol = (map.ID != null ? map.ID : 0) + 1;
  const lastRow = sheet.getLastRow();
  let targetRow = -1;
  if (lastRow > 1) {
    const ids = sheet.getRange(2, idCol, lastRow - 1, 1).getValues();
    for (let i = 0; i < ids.length; i += 1) {
      if (String(ids[i][0] || "").trim() === enemy.ID) {
        targetRow = i + 2;
        break;
      }
    }
  }

  const row = ar2eEnemyToRow_(enemy);
  if (targetRow > 0) {
    sheet.getRange(targetRow, 1, 1, AR2E_HEADERS.length).setValues([row]);
  } else {
    sheet.appendRow(row);
  }

  return { status: "success", message: "保存しました", data: enemy };
}

function deleteAR2EEnemy_(e) {
  const id = String((e && e.parameter && e.parameter.id) || "").trim();
  if (!id) return { status: "error", message: "IDが必要です" };

  const sheet = getAR2ESheet_();
  const map = getAR2EHeaderMap_(sheet);
  const idCol = (map.ID != null ? map.ID : 0) + 1;
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { status: "error", message: "データがありません" };

  const ids = sheet.getRange(2, idCol, lastRow - 1, 1).getValues();
  let targetRow = -1;
  for (let i = 0; i < ids.length; i += 1) {
    if (String(ids[i][0] || "").trim() === id) {
      targetRow = i + 2;
      break;
    }
  }

  if (targetRow > 0) {
    sheet.deleteRow(targetRow);
    return { status: "success", message: "削除しました" };
  }
  return { status: "error", message: "対象が見つかりませんでした" };
}

