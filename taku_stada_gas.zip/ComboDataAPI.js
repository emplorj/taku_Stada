// ===== 設定項目 =====
const SHEET_NAME_FOR_COMBO = "ComboData";
const SHEET_NAME_SHINJUKU = "ShinjukuData";
const SHEET_NAME_LOG_SCENE = "LogSceneData";

// ★あなたのサイトのURL (キャラシページのURL)
const BASE_URL = "https://emplorj.github.io/taku_Stada/shinjuku_crawler.html";
const LOG_PLAYER_URL = "https://emplorj.github.io/taku_Stada/log_player.html";

// ===== 各種処理ロジック (Main.jsから呼び出されます) =====


// ===== シンジュクロウラー用 新規関数 =====

/**
 * シンジュクデータの保存処理
 */
function handleShinjukuRequest(payload) {
  const sheet =
    SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME_SHINJUKU);
  if (!sheet)
    return {
      status: "error",
      message: `シート '${SHEET_NAME_SHINJUKU}' が見つかりません。`,
    };

  const saveKey = payload.id;
  const action = payload.action || "save";

  if (!saveKey) return { status: "error", message: "IDが必要です。" };

  const row = findRowById(sheet, saveKey);

  if (action === "save") {
    const dataToSave = payload.data;
    const isPrivate = payload.isPrivate || false; // 非公開フラグ

    if (!dataToSave)
      return { status: "error", message: "データがありません。" };

    const jsonStringData = JSON.stringify(dataToSave);
    const pcName = dataToSave.pc_name || "（名称未設定）";
    const playerName = dataToSave.player_name || "-";
    const updateTime = new Date();

    // ★管理者用リンク生成
    // スプシ上でクリックするとそのキャラシに飛べるようにする
    const linkUrl = `${BASE_URL}?id=${encodeURIComponent(saveKey)}`;
    const pcNameFormula = `=HYPERLINK("${linkUrl}", "${pcName.replace(
      /"/g,
      '""',
    )}")`;

    // カラム構成: [A:ID] [B:JSON] [C:PC名(Link)] [D:PL名] [E:更新日時] [F:非公開フラグ]
    if (row > 0) {
      sheet.getRange(row, 2).setValue(jsonStringData);
      sheet.getRange(row, 3).setFormula(pcNameFormula); // setFormulaを使う
      sheet.getRange(row, 4).setValue(playerName);
      sheet.getRange(row, 5).setValue(updateTime);
      sheet.getRange(row, 6).setValue(isPrivate ? "TRUE" : "");
    } else {
      sheet.appendRow([
        saveKey,
        jsonStringData,
        "",
        playerName,
        updateTime,
        isPrivate ? "TRUE" : "",
      ]);
      // appendRowだとFormulaが文字列になることがあるので、追加した行のC列だけ再設定
      const lastRow = sheet.getLastRow();
      sheet.getRange(lastRow, 3).setFormula(pcNameFormula);
    }
    return { status: "success", message: "保存しました！", id: saveKey };
  } else {
    return { status: "error", message: `無効なアクション: ${action}` };
  }
}

// ★追加: 一覧取得関数
function getShinjukuList() {
  const sheet =
    SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME_SHINJUKU);
  if (!sheet)
    return createJsonResponse({
      status: "error",
      message: "シートが見つかりません。",
    });

  // データ範囲取得 (ヘッダー除く)
  const lastRow = sheet.getLastRow();
  if (lastRow < 1) return createJsonResponse({ status: "success", data: [] });

  const data = sheet.getRange(1, 1, lastRow, 6).getValues(); // A~F列
  const list = [];

  // 1行目からループ (ヘッダーがあるなら i=1 から)
  // ここでは1行目からデータが入る想定なら i=0、ヘッダーありなら i=1
  // 一旦全行スキャンしてIDがあるかチェック
  for (let i = 0; i < data.length; i++) {
    const row = data[i];
    const id = row[0];
    const pcNameCell = row[2]; // Formulaが入っている場合、getValue()だと表示名が取れるはず
    const plName = row[3];
    const date = row[4];
    const isPrivate = row[5]; // F列: 非公開フラグ

    // IDがあり、かつ非公開フラグが立っていない場合のみリストに追加
    if (id && isPrivate != "TRUE" && isPrivate !== true) {
      // 日付のフォーマット
      let dateStr = "";
      if (date instanceof Date) {
        dateStr = Utilities.formatDate(date, "JST", "yyyy/MM/dd HH:mm");
      }

      list.push({
        id: id,
        pc_name: pcNameCell, // HYPERLINK関数の表示部分が取れる
        player_name: plName,
        updated: dateStr,
      });
    }
  }

  // 新しい順にソート
  list.reverse();

  return createJsonResponse({ status: "success", data: list });
}
/**
 * シンジュクデータの読み込み処理 (GET)
 */
function loadFromDatabaseShinjuku(e) {
  const sheet =
    SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME_SHINJUKU);
  if (!sheet)
    return createJsonResponse({
      status: "error",
      message: `シート '${SHEET_NAME_SHINJUKU}' がありません。`,
    });

  const saveKey = e.parameter.id;
  if (!saveKey)
    return createJsonResponse({
      status: "error",
      message: "IDが指定されていません。",
    });

  const row = findRowById(sheet, saveKey);
  if (row > 0) {
    const dataString = sheet.getRange(row, 2).getValue();
    try {
      const jsonData = JSON.parse(dataString);
      return createJsonResponse({
        status: "success",
        id: saveKey,
        data: jsonData,
      });
    } catch (err) {
      return createJsonResponse({
        status: "error",
        message: "データのパースに失敗しました。",
      });
    }
  }
}

// ===== ログプレイヤー用 新規関数 =====

/**
 * ログシーンデータの保存処理
 */
function handleLogSceneRequest(payload) {
  const sheet =
    SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME_LOG_SCENE);
  if (!sheet)
    return {
      status: "error",
      message: `シート '${SHEET_NAME_LOG_SCENE}' が見つかりません。`,
    };

  const sceneId = payload.id;
  const action = payload.action || "save";

  if (!sceneId) return { status: "error", message: "IDが必要です。" };

  const row = findRowById(sheet, sceneId);

  if (action === "save") {
    const dataToSave = payload.data; // { lines: [...], startLine: 0, title: "..." }
    if (!dataToSave)
      return { status: "error", message: "データがありません。" };

    const jsonStringData = JSON.stringify(dataToSave);
    const sceneTitle = dataToSave.title || "（タイトル未設定）";
    const lineCount = dataToSave.lines ? dataToSave.lines.length : 0;
    const updateTime = new Date();

    // 共有URL生成 (リクエストからURLが指定されていればそれを使う)
    const baseUrl = payload.baseUrl || LOG_PLAYER_URL;
    const linkUrl = `${baseUrl}?scene=${encodeURIComponent(sceneId)}`;
    const titleFormula = `=HYPERLINK("${linkUrl}", "${sceneTitle.replace(
      /"/g,
      '""',
    )}")`;

    // カラム構成: [A:ID] [B:JSON] [C:タイトル(Link)] [D:作成日時]
    if (row > 0) {
      sheet.getRange(row, 2).setValue(jsonStringData);
      sheet.getRange(row, 3).setFormula(titleFormula);
      sheet.getRange(row, 4).setValue(updateTime);
    } else {
      sheet.appendRow([sceneId, jsonStringData, "", updateTime]);
      const lastRow = sheet.getLastRow();
      sheet.getRange(lastRow, 3).setFormula(titleFormula);
    }
    return {
      status: "success",
      message: "シーンを保存しました!",
      id: sceneId,
      url: linkUrl,
    };
  } else if (action === "delete") {
    if (row > 0) {
      sheet.deleteRow(row);
      return { status: "success", message: "シーンを削除しました。" };
    } else {
      // 既に見つからない場合も成功とみなすかエラーにするか。ここではエラーを返す。
      return { status: "not_found", message: "削除対象が見つかりません。" };
    }
  } else {
    return { status: "error", message: `無効なアクション: ${action}` };
  }
}

/**
 * ログシーンデータの読み込み処理 (GET)
 */
function loadLogSceneFromDatabase(e) {
  const sheet =
    SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME_LOG_SCENE);
  if (!sheet)
    return createJsonResponse({
      status: "error",
      message: `シート '${SHEET_NAME_LOG_SCENE}' がありません。`,
    });

  const sceneId = e.parameter.id;
  if (!sceneId)
    return createJsonResponse({
      status: "error",
      message: "IDが指定されていません。",
    });

  const row = findRowById(sheet, sceneId);
  if (row > 0) {
    const dataString = sheet.getRange(row, 2).getValue();
    try {
      const jsonData = JSON.parse(dataString);
      return createJsonResponse({
        status: "success",
        id: sceneId,
        data: jsonData,
      });
    } catch (err) {
      return createJsonResponse({
        status: "error",
        message: "データのパースに失敗しました。",
      });
    }
  } else {
    return createJsonResponse({
      status: "not_found",
      message: "該当するシーンが見つかりません。",
    });
  }
}

/**
 * 【新設】コンボジェネレーターからのリクエストを処理する専用関数
 * (元のdoPostのロジックをここに移動)
 */
function handleComboGeneratorRequest(payload) {
  const sheet =
    SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME_FOR_COMBO);
  if (!sheet) {
    return {
      status: "error",
      message: `Sheet '${SHEET_NAME_FOR_COMBO}' not found.`,
    };
  }

  const charaId = payload.id;
  const action = payload.action || "save";
  if (!charaId) {
    return { status: "error", message: "ID is required" };
  }

  const row = findRowById(sheet, charaId);

  if (action === "save") {
    const dataToSave = payload.data;
    if (!dataToSave) {
      return { status: "error", message: "Data is required for saving" };
    }

    const jsonStringData = JSON.stringify(dataToSave);
    const characterName = dataToSave.characterName || "（名称不明）";
    const shareUrl = payload.shareUrl || "";
    const nameCellData = shareUrl
      ? `=HYPERLINK("${shareUrl}", "${characterName}")`
      : characterName;

    if (row > 0) {
      sheet.getRange(row, 2).setValue(jsonStringData);
      sheet.getRange(row, 3).setValue(nameCellData);
      sheet.getRange(row, 4).setValue(new Date());
    } else {
      sheet.appendRow([charaId, jsonStringData, nameCellData, new Date()]);
    }
    return {
      status: "success",
      message: "Data saved successfully.",
      id: charaId,
    };
  } else if (action === "delete") {
    if (row > 0) {
      sheet.deleteRow(row);
      return {
        status: "success",
        message: "Data deleted successfully.",
        id: charaId,
      };
    } else {
      return { status: "not_found", message: "Data to delete was not found." };
    }
  } else {
    return { status: "error", message: `Invalid action: ${action}` };
  }
}

// ===== 機能別関数 (以下は変更なし) =====

/**
 * キャラクター保管所からデータを引用する
 */
function importFromHokanjo(e) {
  const targetUrl = e.parameter.url;
  if (!targetUrl || !String(targetUrl).includes("charasheet.vampire-blood.net")) {
    return createJsonResponse({
      status: "error",
      message: "キャラクター保管所のURLではありません。",
    });
  }
  try {
    const sheetData = fetchDxJsonFromUrl(targetUrl);
    const game = cleanDxText(sheetData.game).toLowerCase();
    if (game && game !== "dx3" && game.indexOf("dx") < 0) {
      throw new Error("DX3のキャラクターシートではありません。game=" + sheetData.game);
    }
    const resultData = normalizeDxJsonToComboGeneratorData(sheetData, targetUrl);
    return createJsonResponse({ status: "success", data: resultData });
  } catch (error) {
    return createJsonResponse({
      status: "error",
      message: "キャラクター保管所JSONの解析に失敗しました。",
      details: error.toString(),
    });
  }
}

/**
 * DBからデータを読み込む
 */
function loadFromDatabase(e) {
  const sheet =
    SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME_FOR_COMBO);
  if (!sheet) {
    return createJsonResponse({
      status: "error",
      message: `Sheet '${SHEET_NAME_FOR_COMBO}' not found.`,
    });
  }
  const charaId = e.parameter.id;
  if (!charaId) {
    return createJsonResponse({ status: "error", message: "ID is required" });
  }
  const row = findRowById(sheet, charaId);
  if (row > 0) {
    const data = sheet.getRange(row, 2).getValue();
    const jsonData = JSON.parse(data);
    return createJsonResponse({
      status: "success",
      id: charaId,
      data: jsonData,
    });
  } else {
    return createJsonResponse({
      status: "not_found",
      message: "Data not found",
    });
  }
}

// ===== ヘルパー関数 (以下は変更なし) =====

function toCharasheetJsonUrl(url) {
  const m = String(url || "").match(/charasheet\.vampire-blood\.net\/(\d+)/);
  if (!m) throw new Error("キャラクター保管所のIDを取得できません。");
  return "https://charasheet.vampire-blood.net/" + m[1] + ".js";
}

function fetchDxJsonFromUrl(url) {
  const jsonUrl = toCharasheetJsonUrl(url);
  const response = UrlFetchApp.fetch(jsonUrl, { muteHttpExceptions: true });
  if (response.getResponseCode() !== 200) {
    throw new Error("JSONの取得に失敗しました。ステータス: " + response.getResponseCode());
  }
  return parseMaybeJsonp(response.getContentText("UTF-8"));
}

function parseMaybeJsonp(text) {
  let s = String(text || "").trim();
  if (!s) throw new Error("JSONの取得結果が空です。");
  const firstBrace = s.indexOf("{");
  const lastBrace = s.lastIndexOf("}");
  if (firstBrace > 0 && lastBrace > firstBrace) {
    s = s.slice(firstBrace, lastBrace + 1);
  }
  return JSON.parse(s);
}

function cleanDxText(value) {
  if (value === null || value === undefined) return "";
  const decoded = String(value)
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .trim();
  return typeof toFullWidthKana === "function" ? toFullWidthKana(decoded) : decoded;
}

function toDxZeroString(value) {
  const s = cleanDxText(value);
  return s === "" ? "0" : s;
}

function toDxInt(value, defVal) {
  const n = parseInt(cleanDxText(value), 10);
  return Number.isFinite(n) ? n : (defVal || 0);
}

function arrayOrEmpty(value) {
  return Array.isArray(value) ? value : [];
}

function getDxName(sheetData) {
  return cleanDxText(sheetData.pc_name) ||
    cleanDxText(sheetData.koma_name) ||
    cleanDxText(sheetData.data_title) ||
    "(名前未設定)";
}

function normalizeDxJsonToComboGeneratorData(sheetData, url) {
  const syndromes = [
    cleanDxText(sheetData.class1_name),
    cleanDxText(sheetData.class2_name),
    cleanDxText(sheetData.class3_name),
  ].filter(Boolean);

  const abilities = getDxBaseAbilitiesFromJson(sheetData);
  const baseSkills = getDxBaseSkillsFromJson(sheetData);
  const namedSkills = getDxNamedSkillsFromJson(sheetData);
  const characterSkills = mergeDxSkillRows(baseSkills, namedSkills);

  return {
    sourceType: "charasheet-json",
    dataId: cleanDxText(sheetData.data_id),
    characterName: getDxName(sheetData),
    totalXp: toDxInt(sheetData.sum_seichoten_calc, toDxInt(sheetData.expTotal, 130)) || 130,
    expTotal: toDxInt(sheetData.sum_seichoten_calc, 0) || undefined,
    syndromes,
    syndrome1: syndromes[0] || "",
    syndrome2: syndromes[1] || "",
    syndrome3: syndromes[2] || "",
    class1_name: syndromes[0] || "",
    class2_name: syndromes[1] || "",
    class3_name: syndromes[2] || "",
    abilities,
    characterAbilities: abilities,
    skills: characterSkills,
    characterSkills,
    baseSkills,
    namedSkills,
    hp: toDxInt(sheetData.NP5, 0),
    erosion: toDxInt(sheetData.NP6, 0),
    initiative: toDxInt(sheetData.NP7, 0),
    move: toDxInt(sheetData.NP8, 0),
    effects: getDxEffectsFromJson(sheetData),
    easyEffects: getDxEasyEffectsFromJson(sheetData),
    items: getDxItemsFromJson(sheetData).concat(getDxWeaponsFromJson(sheetData)),
    weapons: getDxWeaponsFromJson(sheetData),
    externalUrl: url,
  };
}

function getDxBaseAbilitiesFromJson(sheetData) {
  return {
    body: toDxInt(sheetData.NP1, 0),
    sense: toDxInt(sheetData.NP2, 0),
    mind: toDxInt(sheetData.NP3, 0),
    social: toDxInt(sheetData.NP4, 0),
    "肉体": toDxInt(sheetData.NP1, 0),
    "感覚": toDxInt(sheetData.NP2, 0),
    "精神": toDxInt(sheetData.NP3, 0),
    "社会": toDxInt(sheetData.NP4, 0),
  };
}

function getDxBaseSkillsFromJson(sheetData) {
  const tokugi = arrayOrEmpty(sheetData.skill_tokugi);
  const memo = arrayOrEmpty(sheetData.skill_memo);
  const defs = [
    { index: 0, label: "白兵", kind: "白兵", ability: "肉体" },
    { index: 1, label: "回避", kind: "回避", ability: "肉体" },
    { index: 2, label: "運転", kind: "運転", ability: "肉体" },
    { index: 3, label: "射撃", kind: "射撃", ability: "感覚" },
    { index: 4, label: "知覚", kind: "知覚", ability: "感覚" },
    { index: 5, label: "芸術", kind: "芸術", ability: "感覚" },
    { index: 6, label: "RC", kind: "RC", ability: "精神" },
    { index: 7, label: "意志", kind: "意志", ability: "精神" },
    { index: 8, label: "知識", kind: "知識", ability: "精神" },
    { index: 9, label: "交渉", kind: "交渉", ability: "社会" },
    { index: 10, label: "調達", kind: "調達", ability: "社会" },
    { index: 11, label: "情報", kind: "情報", ability: "社会" },
  ];
  return defs.map((def) => {
    const detailName = cleanDxText(memo[def.index]);
    const label = detailName && ["運転", "芸術", "知識", "情報"].indexOf(def.kind) >= 0
      ? def.kind + ":" + detailName
      : def.label;
    return {
      kind: def.kind,
      label,
      baseLabel: def.label,
      value: toDxZeroString(tokugi[def.index]),
      ability: def.ability,
      sourceIndex: def.index,
    };
  }).filter((row) => row.label);
}

function getDxNamedSkillsFromJson(sheetData) {
  const tokugi = arrayOrEmpty(sheetData.skill_tokugi);
  const memo = arrayOrEmpty(sheetData.skill_memo);
  const skillIds = Array.isArray(sheetData.V_skill_id)
    ? sheetData.V_skill_id
    : Array.isArray(sheetData.skill_id)
      ? sheetData.skill_id
      : [];

  const result = [];
  const baseNamedIndexes = {
    2: "運転",
    5: "芸術",
    8: "知識",
    11: "情報",
  };
  const abilityMap = {
    "運転": "肉体",
    "芸術": "感覚",
    "知識": "精神",
    "情報": "社会",
  };

  Object.keys(baseNamedIndexes).forEach((indexText) => {
    const i = Number(indexText);
    const kind = baseNamedIndexes[i];
    const name = cleanDxText(memo[i]);
    if (!name) return;
    result.push({
      kind,
      label: kind + ":" + name,
      value: toDxZeroString(tokugi[i]),
      ability: abilityMap[kind] || "",
      sourceIndex: i,
    });
  });

  const skillKindMap = {
    "1": "運転",
    "2": "芸術",
    "3": "知識",
    "4": "情報",
  };

  const baseSkillCount = 12;
  for (let i = baseSkillCount; i < tokugi.length; i++) {
    const kindId = cleanDxText(skillIds[i - baseSkillCount]);
    const kind = skillKindMap[kindId];
    const name = cleanDxText(memo[i]);
    if (!kind || !name) continue;
    result.push({
      kind,
      label: kind + ":" + name,
      value: toDxZeroString(tokugi[i]),
      ability: abilityMap[kind] || "",
      sourceIndex: i,
    });
  }

  return result;
}

function mergeDxSkillRows(baseSkills, namedSkills) {
  const result = [];
  const seen = {};
  (Array.isArray(baseSkills) ? baseSkills : []).forEach((row) => {
    if (!row || !row.label) return;
    if (seen[row.label]) return;
    seen[row.label] = true;
    result.push(row);
  });
  (Array.isArray(namedSkills) ? namedSkills : []).forEach((row) => {
    if (!row || !row.label) return;
    if (seen[row.label]) return;
    seen[row.label] = true;
    result.push(row);
  });
  return result;
}

function normalizeDxEffectLevel(raw) {
  const text = cleanDxText(raw);
  const n = parseInt(text, 10);
  return {
    // キャラクター保管所の ★ は自動/固定Lv系として扱い、計算用Lvは1にする。
    level: Number.isFinite(n) ? n : 1,
    levelText: text,
  };
}

function getDxEffectsFromJson(sheetData) {
  return zipDxEffectArrays(sheetData, "effect");
}

function getDxEasyEffectsFromJson(sheetData) {
  return zipDxEffectArrays(sheetData, "easyeffect");
}

function zipDxEffectArrays(sheetData, prefix) {
  const names = arrayOrEmpty(sheetData[prefix + "_name"]);
  const levels = arrayOrEmpty(sheetData[prefix + "_lv"]);
  const timings = arrayOrEmpty(sheetData[prefix + "_timing"]);
  const skills = arrayOrEmpty(sheetData[prefix + "_hantei"]);
  const targets = arrayOrEmpty(sheetData[prefix + "_taisho"]);
  const ranges = arrayOrEmpty(sheetData[prefix + "_range"]);
  const costs = arrayOrEmpty(sheetData[prefix + "_cost"]);
  const pages = arrayOrEmpty(sheetData[prefix + "_page"]);
  const memos = arrayOrEmpty(sheetData[prefix + "_memo"]);
  const sources = arrayOrEmpty(sheetData[prefix + "_shozoku"]);
  const result = [];
  for (let i = 0; i < names.length; i++) {
    const name = cleanDxText(names[i]);
    if (!name) continue;
    const levelInfo = normalizeDxEffectLevel(levels[i]);
    result.push({
      name,
      level: levelInfo.level,
      levelText: levelInfo.levelText,
      maxLevel: 5,
      timing: cleanDxText(timings[i]),
      skill: cleanDxText(skills[i]),
      difficulty: "自動",
      target: cleanDxText(targets[i]),
      range: cleanDxText(ranges[i]),
      cost: cleanDxText(costs[i]),
      limit: cleanDxText(pages[i]),
      effect: cleanDxText(memos[i]),
      notes: cleanDxText(sources[i]),
      source: cleanDxText(sources[i]),
    });
  }
  return result;
}

function getDxItemsFromJson(sheetData) {
  const names = arrayOrEmpty(sheetData.item_name);
  const nums = arrayOrEmpty(sheetData.item_num);
  const memos = arrayOrEmpty(sheetData.item_memo);
  const result = [];
  for (let i = 0; i < names.length; i++) {
    const name = cleanDxText(names[i]);
    if (!name) continue;
    result.push({
      name,
      level: toDxInt(nums[i], 1) || 1,
      type: "その他",
      skill: "-",
      accuracy: "",
      attack: "",
      guard: "",
      range: "",
      cost: "",
      xp: 0,
      notes: cleanDxText(memos[i]),
    });
  }
  return result;
}

function getDxWeaponsFromJson(sheetData) {
  const names = arrayOrEmpty(sheetData.arms_name);
  // arms_hit は「5r」のような命中判定結果。武器補正としては右側の arms_hit_mod を使う。
  const hitMods = arrayOrEmpty(sheetData.arms_hit_mod);
  const hitRolls = arrayOrEmpty(sheetData.arms_hit);
  const powers = arrayOrEmpty(sheetData.arms_power);
  const ranges = arrayOrEmpty(sheetData.arms_range);
  const result = [];
  for (let i = 0; i < names.length; i++) {
    const name = cleanDxText(names[i]);
    if (!name) continue;
    result.push({
      name,
      level: 1,
      type: "武器",
      skill: "-",
      accuracy: cleanDxText(hitMods[i]),
      hitRoll: cleanDxText(hitRolls[i]),
      attack: cleanDxText(powers[i]),
      guard: "",
      range: cleanDxText(ranges[i]) || "至近",
      cost: "",
      xp: 0,
      notes: "",
    });
  }
  return result;
}

function parseHokanjoSyndromes(html) {
  const htmlText = String(html || "");
  const found = [];

  const decodeAttr = (value) =>
    decodeHtmlEntities(String(value || ""))
      .replace(/&quot;/g, '"')
      .replace(/&#34;/g, '"')
      .replace(/&#39;/g, "'")
      .replace(/&apos;/g, "'")
      .replace(/&amp;/g, "&")
      .trim();

  const readAttr = (tag, attrName) => {
    const pattern = new RegExp(
      attrName + "\\s*=\\s*(?:\\\"([^\\\"]*)\\\"|'([^']*)'|([^\\s>]+))",
      "i",
    );
    const match = String(tag || "").match(pattern);
    return match ? decodeAttr(match[1] || match[2] || match[3] || "") : "";
  };

  const findInputTag = (nameOrId) => {
    const inputRegex = /<input\b[^>]*>/gi;
    let match;
    while ((match = inputRegex.exec(htmlText)) !== null) {
      const tag = match[0];
      if (readAttr(tag, "name") === nameOrId || readAttr(tag, "id") === nameOrId) {
        return tag;
      }
    }
    return "";
  };

  const readInputValue = (nameOrId) => {
    const tag = findInputTag(nameOrId);
    return tag ? readAttr(tag, "value") : "";
  };

  const readSelectOption = (index, value) => {
    const targetValue = String(value || "").trim();
    if (!targetValue || targetValue === "0") return "";

    const selectPattern = new RegExp(
      "<select\\b[^>]*(?:name|id)\\s*=\\s*(?:\\\"SL_class" +
        index +
        "\\\"|'SL_class" +
        index +
        "'|SL_class" +
        index +
        ")[^>]*>([\\s\\S]*?)<\\/select>",
      "i",
    );
    const selectMatch = htmlText.match(selectPattern);
    if (!selectMatch) return "";

    const optionRegex = /<option\b[^>]*>[\s\S]*?<\/option>/gi;
    let optionMatch;
    while ((optionMatch = optionRegex.exec(selectMatch[1])) !== null) {
      const optionTag = optionMatch[0];
      if (readAttr(optionTag, "value") !== targetValue) continue;
      return decodeAttr(
        optionTag
          .replace(/<option\b[^>]*>/i, "")
          .replace(/<\/option>/i, "")
          .replace(/<[^>]+>/g, ""),
      );
    }
    return "";
  };

  [1, 2, 3].forEach((index) => {
    const hiddenName = readInputValue("class" + index + "_name");
    if (hiddenName) {
      found.push(hiddenName);
      return;
    }

    const classId = readInputValue("class" + index + "_id");
    const optionName = readSelectOption(index, classId);
    if (optionName) found.push(optionName);
  });

  return normalizeDx3SyndromeNames(found);
}

function normalizeDx3SyndromeNames(values) {
  const aliases = {
    "グレイブニル": "グレイプニル",
    "エンジェルハイロゥ": "エンジェルハィロゥ",
    "ブラムストーカー": "ブラム＝ストーカー",
  };
  const result = [];
  (Array.isArray(values) ? values : []).forEach((value) => {
    const name = String(value || "").trim();
    if (!name || name === "0" || name === "-") return;
    const normalized = aliases[name] || name;
    if (!result.includes(normalized)) result.push(normalized);
  });
  return result;
}

function parseEffectTable(html, tableId) {
  const effects = [];
  const tableRegex = new RegExp(
    '<table class="pc_making" id="' + tableId + '">[\\s\\S]*?</table>',
    "i",
  );
  const tableMatch = html.match(tableRegex);
  if (!tableMatch) return effects;

  const tableHtml = tableMatch[0];
  const rowRegex = /<tr[^>]*>[\s\S]*?<\/tr>/gi;
  let rowMatch;

  while ((rowMatch = rowRegex.exec(tableHtml)) !== null) {
    const rowHtml = rowMatch[0];
    const nameMatch = rowHtml.match(
      /name="(?:effect|easyeffect)_name\[\]"[^>]+value="([^"]*)"/,
    );
    if (!nameMatch || !nameMatch[1]) {
      continue;
    }

    const getData = (fieldName) => {
      const regex = new RegExp(
        'name="(?:effect|easyeffect)_' +
          fieldName +
          '\\[\\]"[^>]+value="([^"]*)"',
      );
      const match = rowHtml.match(regex);
      return match ? match[1] : "";
    };

    const hiddenLevelMatch = rowHtml.match(
      /name="(?:effect|easyeffect)_lv\[\]"[^>]+value="([^"]*)"/,
    );
    const selectedValue = hiddenLevelMatch ? hiddenLevelMatch[1] : "0";
    let currentLevel = 1,
      currentMaxLevel = 5;
    const selectMatch = rowHtml.match(
      /<select name="S_(?:effect|easyeffect)_lv\[\]"[\s\S]*?<\/select>/,
    );
    if (selectMatch) {
      const optionRegex = new RegExp(
        '<option value="' +
          selectedValue.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") +
          '"[^>]*>([\\s\\S]*?)</option>',
      );
      const optionMatch = selectMatch[0].match(optionRegex);
      if (optionMatch) {
        const selectedText = optionMatch[1].trim();
        const parsedLevel = parseInt(selectedText, 10);
        currentLevel = isNaN(parsedLevel) ? 1 : parsedLevel;
      }
    }
    const parsedSelectedValue = parseInt(selectedValue, 10);
    if (parsedSelectedValue === 0) {
      currentMaxLevel = 1;
    } else {
      currentMaxLevel = 5;
    }

    const limitText = toFullWidthKana(getData("page"));
    const notesText = toFullWidthKana(getData("shozoku"));

    effects.push({
      name: decodeHtmlEntities(nameMatch[1]),
      level: currentLevel,
      maxLevel: currentMaxLevel,
      timing: toFullWidthKana(getData("timing")),
      skill: toFullWidthKana(getData("hantei")),
      difficulty: "自動",
      target: toFullWidthKana(getData("taisho")),
      range: toFullWidthKana(getData("range")),
      cost: getData("cost"),
      limit: limitText,
      effect: decodeHtmlEntities(getData("memo")),
      notes: notesText,
    });
  }
  return effects;
}

function parseItems(html) {
  const items = [];
  const armsTableRegex = /<table[^>]+id="Table_arms"[^>]*>[\s\S]*?<\/table>/i;
  const armsTableMatch = html.match(armsTableRegex);
  if (armsTableMatch) {
    const rowRegex = /<tr[^>]*>[\s\S]*?<\/tr>/gi;
    let rowMatch;
    while ((rowMatch = rowRegex.exec(armsTableMatch[0])) !== null) {
      const rowHtml = rowMatch[0];
      const nameMatch = rowHtml.match(
        /name="arms_name\[\]"[^>]+value="([^"]*)"/,
      );
      if (!nameMatch || !nameMatch[1]) continue;

      const getData = (fieldName) => {
        const regex = new RegExp(
          `name="${fieldName}\\[\\]"[^>]+value="([^"]*)"`,
        );
        const match = rowHtml.match(regex);
        return match ? match[1] : "";
      };

      const skillId = getData("V_arms_hit_param");
      let skillName = "-";
      if (skillId === "1") skillName = "白兵";
      else if (skillId === "2") skillName = "射撃";
      else if (skillId === "3") skillName = "RC";

      items.push({
        name: decodeHtmlEntities(nameMatch[1]),
        level: 1,
        type: "武器",
        skill: skillName,
        accuracy: getData("arms_hit"),
        attack: getData("arms_power"),
        guard: getData("arms_guard_level"),
        range: getData("arms_range"),
        cost: "",
        xp: 0,
        notes: decodeHtmlEntities(getData("arms_sonota")),
      });
    }
  }

  const getGlobalData = (fieldName) => {
    const regex = new RegExp(`name="${fieldName}"[^>]+value="([^"]*)"`);
    const match = html.match(regex);
    return match ? match[1] : "";
  };

  const armer1Name = getGlobalData("armer_name");
  if (armer1Name) {
    items.push({
      name: decodeHtmlEntities(armer1Name),
      level: 1,
      type: "防具",
      skill: "-",
      accuracy: "",
      attack: "",
      guard: getGlobalData("armer_def"),
      range: "",
      cost: "",
      xp: 0,
      notes: decodeHtmlEntities(getGlobalData("armer_sonota")),
    });
  }
  const armer2Name = getGlobalData("armer2_name");
  if (armer2Name) {
    items.push({
      name: decodeHtmlEntities(armer2Name),
      level: 1,
      type: "防具",
      skill: "-",
      accuracy: "",
      attack: "",
      guard: getGlobalData("armer2_def"),
      range: "",
      cost: "",
      xp: 0,
      notes: decodeHtmlEntities(getGlobalData("armer2_sonota")),
    });
  }

  const itemTableRegex = /<table[^>]+id="Table_item"[^>]*>[\s\S]*?<\/table>/i;
  const itemTableMatch = html.match(itemTableRegex);
  if (itemTableMatch) {
    const rowRegex = /<tr[^>]*>[\s\S]*?<\/tr>/gi;
    let rowMatch;
    while ((rowMatch = rowRegex.exec(itemTableMatch[0])) !== null) {
      const rowHtml = rowMatch[0];
      const nameMatch = rowHtml.match(
        /name="item_name\[\]"[^>]+value="([^"]*)"/,
      );
      if (!nameMatch || !nameMatch[1]) continue;

      const getRowData = (fieldName) => {
        const regex = new RegExp(
          `name="${fieldName}\\[\\]"[^>]+value="([^"]*)"`,
        );
        const match = rowHtml.match(regex);
        return match ? match[1] : "";
      };

      items.push({
        name: decodeHtmlEntities(nameMatch[1]),
        level: 1,
        type: "その他",
        skill: "-",
        accuracy: "",
        attack: "",
        guard: "",
        range: "",
        cost: "",
        xp: 0,
        notes: decodeHtmlEntities(getRowData("item_memo")),
      });
    }
  }

  return items;
}

function decodeHtmlEntities(str) {
  if (!str) return "";
  return str
    .replace(/&times;/g, "×")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'");
}

function toFullWidthKana(str) {
  if (!str) return "";
  const kanaMap = {
    ｶﾞ: "ガ",
    ｷﾞ: "ギ",
    ｸﾞ: "グ",
    ｹﾞ: "ゲ",
    ｺﾞ: "ゴ",
    ｻﾞ: "ザ",
    ｼﾞ: "ジ",
    ｽﾞ: "ズ",
    ｾﾞ: "ゼ",
    ｿﾞ: "ゾ",
    ﾀﾞ: "ダ",
    ﾁﾞ: "ヂ",
    ﾂﾞ: "ヅ",
    ﾃﾞ: "デ",
    ﾄﾞ: "ド",
    ﾊﾞ: "バ",
    ﾋﾞ: "ビ",
    ﾌﾞ: "ブ",
    ﾍﾞ: "ベ",
    ﾎﾞ: "ボ",
    ﾊﾟ: "パ",
    ﾋﾟ: "ピ",
    ﾌﾟ: "プ",
    ﾍﾟ: "ペ",
    ﾎﾟ: "ポ",
    ｳﾞ: "ヴ",
    ﾜﾞ: "ヷ",
    ｦﾞ: "ヺ",
    ｱ: "ア",
    ｲ: "イ",
    ｳ: "ウ",
    ｴ: "エ",
    ｵ: "オ",
    ｶ: "カ",
    ｷ: "キ",
    ｸ: "ク",
    ｹ: "ケ",
    ｺ: "コ",
    ｻ: "サ",
    ｼ: "シ",
    ｽ: "ス",
    ｾ: "セ",
    ｿ: "ソ",
    ﾀ: "タ",
    ﾁ: "チ",
    ﾂ: "ツ",
    ﾃ: "テ",
    ﾄ: "ト",
    ﾅ: "ナ",
    ﾆ: "ニ",
    ﾇ: "ヌ",
    ﾈ: "ネ",
    ﾉ: "ノ",
    ﾊ: "ハ",
    ﾋ: "ヒ",
    ﾌ: "フ",
    ﾍ: "ヘ",
    ﾎ: "ホ",
    ﾏ: "マ",
    ﾐ: "ミ",
    ﾑ: "ム",
    ﾒ: "メ",
    ﾓ: "モ",
    ﾔ: "ヤ",
    ﾕ: "ユ",
    ﾖ: "ヨ",
    ﾗ: "ラ",
    ﾘ: "リ",
    ﾙ: "ル",
    ﾚ: "レ",
    ﾛ: "ロ",
    ﾜ: "ワ",
    ｦ: "ヲ",
    ﾝ: "ン",
    ｧ: "ァ",
    ｨ: "ィ",
    ｩ: "ゥ",
    ｪ: "ェ",
    ｫ: "ォ",
    ｯ: "ッ",
    ｬ: "ャ",
    ｭ: "ュ",
    ｮ: "ョ",
    "｡": "。",
    "､": "、",
    ｰ: "ー",
    "｢": "「",
    "｣": "」",
    "･": "・",
  };
  const reg = new RegExp("(" + Object.keys(kanaMap).join("|") + ")", "g");
  return str.replace(reg, (match) => kanaMap[match]).replace(/\//g, "／");
}

function findRowById(sheet, id) {
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(id)) return i + 1;
  }
  return -1;
}


