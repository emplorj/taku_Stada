// ===== Satasupe API =====
const SHEET_NAME_SATASUPE = "satasupe_enemies";
const TOOL_NAME_SATASUPE = "satasupe";
const SATASUPE_HEADERS = [
  "ID",
  "author",
  "name",
  "class_type",
  "is_public",
  "memo",
  "data",
  "icon_url",
  "time",
];

function handleSatasupeGet(action, e) {
  if (action === "listSatasupeEnemies") {
    return listSatasupeEnemies_(e);
  }
  if (action === "deleteSatasupeEnemy") {
    return deleteSatasupeEnemy_(e);
  }
  return {
    status: "error",
    message: `satasupe用の不正なactionです: ${action}`,
  };
}

function handleSatasupePost(payload) {
  const action = String((payload && payload.action) || "").trim();
  if (action === "saveSatasupeEnemy") {
    return saveSatasupeEnemy_(payload);
  }
  if (action === "migrateSatasupeDataRemoveSystem") {
    return migrateSatasupeDataRemoveSystem_();
  }
  return {
    status: "error",
    message: `satasupe用の不正なactionです: ${action}`,
  };
}

function getSatasupeSheet_() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = spreadsheet.getSheetByName(SHEET_NAME_SATASUPE);
  if (!sheet) sheet = spreadsheet.insertSheet(SHEET_NAME_SATASUPE);
  ensureSatasupeHeaders_(sheet);
  return sheet;
}

function ensureSatasupeHeaders_(sheet) {
  if (sheet.getMaxColumns() < SATASUPE_HEADERS.length) {
    sheet.insertColumnsAfter(
      sheet.getMaxColumns(),
      SATASUPE_HEADERS.length - sheet.getMaxColumns(),
    );
  }
  const row =
    sheet.getLastRow() >= 1
      ? sheet.getRange(1, 1, 1, SATASUPE_HEADERS.length).getValues()[0]
      : [];
  const hasHeader = SATASUPE_HEADERS.every(
    (name, idx) => String(row[idx] || "") === name,
  );
  if (!hasHeader) {
    sheet
      .getRange(1, 1, 1, SATASUPE_HEADERS.length)
      .setValues([SATASUPE_HEADERS]);
  }
}

function getSatasupeHeaderMap_(sheet) {
  const row =
    sheet.getRange(1, 1, 1, SATASUPE_HEADERS.length).getValues()[0] || [];
  const map = {};
  SATASUPE_HEADERS.forEach((name, idx) => {
    const actual = String(row[idx] || name);
    map[actual] = idx;
    if (actual !== name && map[name] == null) map[name] = idx;
  });
  return map;
}

function normalizeSatasupeEnemy_(enemy) {
  const src = enemy && typeof enemy === "object" ? enemy : {};
  const classType =
    String(src.class_type || "").trim() ||
    String(
      src &&
        src.data &&
        src.data.sheet &&
        src.data.sheet.meta &&
        src.data.sheet.meta.category,
    ).trim() ||
    "サタスペ";
  return {
    ID: String(src.ID || "").trim(),
    author: String(src.author || "").trim(),
    name: String(src.name || "").trim(),
    class_type: classType,
    is_public: !!src.is_public,
    memo: String(src.memo || ""),
    data: src.data || { sheet: {} },
    icon_url: String(src.icon_url || "").trim(),
    time: String(src.time || "").trim() || nowSatasupeTimeText_(),
  };
}

function removeSatasupeSystemField_(dataObj) {
  const src = dataObj && typeof dataObj === "object" ? dataObj : {};
  const next = Object.assign({}, src);
  if (Object.prototype.hasOwnProperty.call(next, "system")) {
    delete next.system;
  }
  return next;
}

function satasupeEnemyToRow_(enemy) {
  return [
    enemy.ID,
    enemy.author,
    enemy.name,
    enemy.class_type,
    enemy.is_public ? "true" : "false",
    enemy.memo,
    JSON.stringify(removeSatasupeSystemField_(enemy.data || {})),
    enemy.icon_url,
    enemy.time,
  ];
}

function rowToSatasupeEnemy_(row, map) {
  const pick = (name) => row[map[name] != null ? map[name] : -1];
  const parsedData = safeJson_(String(pick("data") || "{}"), {});
  return {
    ID: String(pick("ID") || "").trim(),
    author: String(pick("author") || "").trim(),
    name: String(pick("name") || "").trim(),
    class_type: String(pick("class_type") || "").trim(),
    is_public: parseBool_(pick("is_public")),
    memo: String(pick("memo") || ""),
    data: removeSatasupeSystemField_(parsedData),
    icon_url: String(pick("icon_url") || "").trim(),
    time: String(pick("time") || "").trim(),
  };
}

function migrateSatasupeDataRemoveSystem_() {
  const sheet = getSatasupeSheet_();
  const map = getSatasupeHeaderMap_(sheet);
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) {
    return {
      status: "success",
      message: "変換対象データがありません",
      data: { scanned: 0, changed: 0 },
    };
  }

  const dataCol = (map.data != null ? map.data : 6) + 1;
  const values = sheet.getRange(2, dataCol, lastRow - 1, 1).getValues();

  let changed = 0;
  for (let i = 0; i < values.length; i += 1) {
    const raw = String(values[i][0] || "");
    const parsed = safeJson_(raw, null);
    if (!parsed || typeof parsed !== "object") continue;

    if (!Object.prototype.hasOwnProperty.call(parsed, "system")) continue;

    const next = removeSatasupeSystemField_(parsed);
    values[i][0] = JSON.stringify(next);
    changed += 1;
  }

  if (changed > 0) {
    sheet.getRange(2, dataCol, values.length, 1).setValues(values);
  }

  return {
    status: "success",
    message: `変換完了: ${changed}件更新`,
    data: { scanned: values.length, changed },
  };
}

function listSatasupeEnemies_(e) {
  const author = String((e && e.parameter && e.parameter.author) || "").trim();
  const authorNormalized = author.toLowerCase();
  const params = (e && e.parameter) || {};
  const isAdminMode =
    String(params.admin || params.adminCode || "").trim() === "9800" &&
    (String(params.allAuthors || "").trim() === "1" ||
      String(params.includePrivate || "").trim() === "1");
  const sheet = getSatasupeSheet_();
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { status: "success", data: [] };

  const map = getSatasupeHeaderMap_(sheet);
  const rows = sheet
    .getRange(2, 1, lastRow - 1, SATASUPE_HEADERS.length)
    .getValues()
    .map((row) => rowToSatasupeEnemy_(row, map))
    .filter((enemy) => {
      if (!enemy.ID) return false;
      if (isAdminMode) return true;
      if (enemy.is_public) return true;
      const enemyAuthor = String((enemy && enemy.author) || "")
        .trim()
        .toLowerCase();
      return !!authorNormalized && enemyAuthor === authorNormalized;
    })
    .sort((a, b) => String(b.time || "").localeCompare(String(a.time || "")));

  return { status: "success", data: rows };
}

function saveSatasupeEnemy_(payload) {
  const enemy = normalizeSatasupeEnemy_(payload && payload.enemy);
  enemy.time = nowSatasupeTimeText_();

  const sheet = getSatasupeSheet_();
  const map = getSatasupeHeaderMap_(sheet);

  if (!enemy.ID || enemy.ID.startsWith("tmp-")) {
    enemy.ID = generateNextSatasupeId_(sheet, map);
  }

  const idCol = (map.ID != null ? map.ID : 0) + 1;
  const lastRow = sheet.getLastRow();
  let targetRow = -1;
  if (lastRow > 1) {
    const ids = sheet.getRange(2, idCol, lastRow - 1, 1).getValues();
    for (let i = 0; i < ids.length; i += 1) {
      if (String(ids[i][0] || "").trim() === enemy.ID) {
        targetRow = i + 2;
        break;
      }
    }
  }

  const row = satasupeEnemyToRow_(enemy);
  if (targetRow > 0) {
    sheet.getRange(targetRow, 1, 1, SATASUPE_HEADERS.length).setValues([row]);
  } else {
    sheet.appendRow(row);
  }

  return { status: "success", message: "保存しました", data: enemy };
}

function deleteSatasupeEnemy_(e) {
  const id = String((e && e.parameter && e.parameter.id) || "").trim();
  if (!id) return { status: "error", message: "IDが必要です" };

  const sheet = getSatasupeSheet_();
  const map = getSatasupeHeaderMap_(sheet);
  const idCol = (map.ID != null ? map.ID : 0) + 1;
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { status: "error", message: "データがありません" };

  const ids = sheet.getRange(2, idCol, lastRow - 1, 1).getValues();
  let targetRow = -1;
  for (let i = 0; i < ids.length; i += 1) {
    if (String(ids[i][0] || "").trim() === id) {
      targetRow = i + 2;
      break;
    }
  }

  if (targetRow > 0) {
    sheet.deleteRow(targetRow);
    return { status: "success", message: "削除しました" };
  }
  return { status: "error", message: "対象が見つかりませんでした" };
}

function nowSatasupeTimeText_() {
  const tz = Session.getScriptTimeZone() || "Asia/Tokyo";
  return Utilities.formatDate(new Date(), tz, "yyyy/MM/dd HH:mm:ss");
}

function generateNextSatasupeId_(sheet, map) {
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return "S0001";

  const idCol = (map.ID != null ? map.ID : 0) + 1;
  const ids = sheet.getRange(2, idCol, lastRow - 1, 1).getValues();
  let maxNum = 0;

  ids.forEach((row) => {
    const id = String(row[0] || "");
    const match = id.match(/S(\d+)/);
    if (match) {
      const num = parseInt(match[1], 10);
      if (num > maxNum) maxNum = num;
    }
  });

  const nextNum = maxNum + 1;
  return "S" + String(nextNum).padStart(4, "0");
}
