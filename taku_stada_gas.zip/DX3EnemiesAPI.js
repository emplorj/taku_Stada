// ===== DX3 Enemy API =====
const SHEET_NAME_DX3_ENEMIES = "DX3_enemies";
const DX3_ENEMY_HEADERS = [
  "ID",
  "author",
  "name",
  "class_type",
  "is_public",
  "memo",
  "data",
  "icon_url",
  "time",
];

function handleDX3EnemyGet(action, e) {
  if (action === "listDX3Enemies") return listDX3Enemies_(e);
  if (action === "deleteDX3Enemy") return deleteDX3Enemy_(e);
  return { status: "error", message: `dx3enemy用の不正なactionです: ${action}` };
}

function handleDX3EnemyPost(payload) {
  const action = String((payload && payload.action) || "").trim();
  if (action === "saveDX3Enemy") return saveDX3Enemy_(payload);
  return { status: "error", message: `dx3enemy用の不正なactionです: ${action}` };
}

function getDX3EnemySheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(SHEET_NAME_DX3_ENEMIES);
  if (!sheet) sheet = ss.insertSheet(SHEET_NAME_DX3_ENEMIES);
  ensureDX3EnemyHeaders_(sheet);
  return sheet;
}

function ensureDX3EnemyHeaders_(sheet) {
  if (sheet.getMaxColumns() < DX3_ENEMY_HEADERS.length) {
    sheet.insertColumnsAfter(sheet.getMaxColumns(), DX3_ENEMY_HEADERS.length - sheet.getMaxColumns());
  }
  const row = sheet.getLastRow() >= 1 ? sheet.getRange(1, 1, 1, DX3_ENEMY_HEADERS.length).getValues()[0] : [];
  const ok = DX3_ENEMY_HEADERS.every((name, idx) => String(row[idx] || "") === name);
  if (!ok) sheet.getRange(1, 1, 1, DX3_ENEMY_HEADERS.length).setValues([DX3_ENEMY_HEADERS]);
}

function getDX3EnemyHeaderMap_(sheet) {
  const row = sheet.getRange(1, 1, 1, DX3_ENEMY_HEADERS.length).getValues()[0] || [];
  const map = {};
  DX3_ENEMY_HEADERS.forEach((name, idx) => {
    const actual = String(row[idx] || name);
    map[actual] = idx;
    if (actual !== name && map[name] == null) map[name] = idx;
  });
  return map;
}

function parseBoolDX3Enemy_(v) {
  if (typeof v === "boolean") return v;
  const s = String(v || "").trim().toLowerCase();
  return s === "true" || s === "1" || s === "yes" || s === "on" || s === "公開";
}

function safeJsonDX3Enemy_(text, fallback) {
  try { return JSON.parse(text); } catch (_e) { return fallback; }
}

function nowDX3EnemyTimeText_() {
  const tz = Session.getScriptTimeZone() || "Asia/Tokyo";
  return Utilities.formatDate(new Date(), tz, "yyyy/MM/dd HH:mm:ss");
}

function isSequentialDX3EnemyId_(value) {
  const s = String(value || "").trim();
  if (!/^\d+$/.test(s)) return false;
  const n = Number(s);
  return Number.isFinite(n) && n > 0 && n < 1000000000000;
}

function getNextDX3EnemySequentialId_(sheet, map) {
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return "1";
  const idCol = (map.ID != null ? map.ID : 0) + 1;
  const ids = sheet.getRange(2, idCol, lastRow - 1, 1).getValues();
  let maxId = 0;
  ids.forEach((row) => {
    const raw = row[0];
    if (!isSequentialDX3EnemyId_(raw)) return;
    maxId = Math.max(maxId, Number(raw));
  });
  return String(maxId + 1);
}

function normalizeDX3Enemy_(enemy) {
  const src = enemy && typeof enemy === "object" ? enemy : {};
  const data = src.data && typeof src.data === "object" ? src.data : {};
  return {
    ID: String(src.ID || "").trim(),
    author: String(src.author || "").trim(),
    name: String(src.name || "").trim() || "DX3エネミー",
    class_type: String(src.class_type || "DX3").trim() || "DX3",
    is_public: src.is_public !== false,
    memo: String(src.memo || ""),
    data: data,
    icon_url: String(src.icon_url || "").trim(),
    time: String(src.time || "").trim() || nowDX3EnemyTimeText_(),
  };
}

function dx3EnemyToRow_(enemy) {
  return [
    enemy.ID,
    enemy.author,
    enemy.name,
    enemy.class_type,
    enemy.is_public ? "true" : "false",
    enemy.memo,
    JSON.stringify(enemy.data || {}),
    enemy.icon_url,
    enemy.time,
  ];
}

function rowToDX3Enemy_(row, map) {
  const pick = (name) => row[map[name] != null ? map[name] : -1];
  return {
    ID: String(pick("ID") || "").trim(),
    author: String(pick("author") || "").trim(),
    name: String(pick("name") || "").trim(),
    class_type: String(pick("class_type") || "").trim(),
    is_public: parseBoolDX3Enemy_(pick("is_public")),
    memo: String(pick("memo") || ""),
    data: safeJsonDX3Enemy_(String(pick("data") || "{}"), {}),
    icon_url: String(pick("icon_url") || "").trim(),
    time: String(pick("time") || "").trim(),
  };
}

function listDX3Enemies_(e) {
  const sheet = getDX3EnemySheet_();
  const map = getDX3EnemyHeaderMap_(sheet);
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { status: "success", enemies: [] };
  const values = sheet.getRange(2, 1, lastRow - 1, DX3_ENEMY_HEADERS.length).getValues();
  const includePrivate = String(((e && e.parameter) || {}).includePrivate || "true") !== "false";
  const enemies = values.map((row) => rowToDX3Enemy_(row, map)).filter((enemy) => includePrivate || enemy.is_public);
  enemies.sort((a, b) => String(b.time || "").localeCompare(String(a.time || "")) || Number(b.ID || 0) - Number(a.ID || 0));
  return { status: "success", enemies: enemies };
}

function saveDX3Enemy_(payload) {
  const sheet = getDX3EnemySheet_();
  const map = getDX3EnemyHeaderMap_(sheet);
  const enemy = normalizeDX3Enemy_(payload.enemy || {});
  const idCol = (map.ID != null ? map.ID : 0) + 1;
  const lastRow = sheet.getLastRow();
  let targetRow = -1;
  if (enemy.ID && lastRow > 1) {
    const ids = sheet.getRange(2, idCol, lastRow - 1, 1).getValues();
    for (let i = 0; i < ids.length; i += 1) {
      if (String(ids[i][0]) === String(enemy.ID)) { targetRow = i + 2; break; }
    }
  }
  if (targetRow < 0) enemy.ID = getNextDX3EnemySequentialId_(sheet, map);
  enemy.time = nowDX3EnemyTimeText_();
  const row = dx3EnemyToRow_(enemy);
  if (targetRow < 0) sheet.appendRow(row);
  else sheet.getRange(targetRow, 1, 1, DX3_ENEMY_HEADERS.length).setValues([row]);
  return { status: "success", message: "保存しました", enemy: enemy };
}

function deleteDX3Enemy_(e) {
  const id = String(((e && e.parameter) || {}).id || "").trim();
  if (!id) return { status: "error", message: "IDがありません" };
  const sheet = getDX3EnemySheet_();
  const map = getDX3EnemyHeaderMap_(sheet);
  const lastRow = sheet.getLastRow();
  if (lastRow <= 1) return { status: "error", message: "データがありません" };
  const idCol = (map.ID != null ? map.ID : 0) + 1;
  const ids = sheet.getRange(2, idCol, lastRow - 1, 1).getValues();
  for (let i = 0; i < ids.length; i += 1) {
    if (String(ids[i][0]) === id) {
      sheet.deleteRow(i + 2);
      return { status: "success", message: "削除しました" };
    }
  }
  return { status: "error", message: "対象が見つかりません" };
}
