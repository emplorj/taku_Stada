// ===== Card DB 専用API（別プロジェクト想定） =====
// このファイルは ComboDataAPI とは分離して、別のGAS Webアプリとしてデプロイする用途です。

const SHEET_NAME_CARD_PUBLIC = "カードDB";
const SHEET_NAME_CARD_PRIVATE = "カードDB_非公開";
const TOOL_NAME_CARD_DB = "cardDb";
const CARD_DB_TIME_ZONE = "Asia/Tokyo";
const CARD_DB_HEADERS = [
  "ID",
  "タイムスタンプ",
  "カード名",
  "カテゴリ",
  "色",
  "タイプ",
  "レアリティ",
  "効果説明",
  "フレーバー",
  "セリフ",
  "画像URL",
  "装飾画像URL",
  "登録者",
  "絵師",
  "元ネタ",
  "imageState",
  "overlayImageState",
  "備考",
];

function doGet(e) {
  const params = (e && e.parameter) || {};
  const tool = params.tool || "";
  const action = params.action || "";

  if (tool !== TOOL_NAME_CARD_DB) {
    return createJsonResponse({
      status: "error",
      message: `tool=${TOOL_NAME_CARD_DB} が必要です。`,
    });
  }

  if (action === "listPublic") return getCardPublicList();
  if (action === "listMine") return getCardMineList(e);
  if (action === "loadById") return loadCardByIdWithOwnerCheck(e);

  return createJsonResponse({
    status: "error",
    message: `cardDb用の不正なactionです: ${action}`,
  });
}

function doPost(e) {
  try {
    const payload = JSON.parse(
      (e && e.postData && e.postData.contents) || "{}",
    );
    if (payload.tool !== TOOL_NAME_CARD_DB) {
      return createJsonResponse({
        status: "error",
        message: `tool=${TOOL_NAME_CARD_DB} が必要です。`,
      });
    }
    return createJsonResponse(handleCardDbRequest(payload));
  } catch (error) {
    return createJsonResponse({
      status: "error",
      message: `サーバー側エラー: ${error.message}`,
    });
  }
}

function handleCardDbRequest(payload) {
  const action = payload.action || "create";

  if (action === "create" || action === "update") {
    const card = payload || {};
    const id = String(card.ID || Date.now());
    const targetSheetName = card.private
      ? SHEET_NAME_CARD_PRIVATE
      : SHEET_NAME_CARD_PUBLIC;

    const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    const targetSheet = getOrCreateSheetByName(spreadsheet, targetSheetName);
    const publicSheet = getOrCreateSheetByName(
      spreadsheet,
      SHEET_NAME_CARD_PUBLIC,
    );
    const privateSheet = getOrCreateSheetByName(
      spreadsheet,
      SHEET_NAME_CARD_PRIVATE,
    );
    ensureCardDbHeader(targetSheet);
    ensureCardDbHeader(publicSheet);
    ensureCardDbHeader(privateSheet);

    const now = new Date();
    const cardRow = {
      ID: id,
      タイムスタンプ: now,
      カード名: card.name || "",
      カテゴリ: card.category || "",
      色: card.color || "",
      タイプ: card.type || "",
      レアリティ: card.rarity || "",
      効果説明: card.effect || "",
      フレーバー: card.flavor || "",
      セリフ: card.speaker || "",
      画像URL: card.imageUrl || "",
      装飾画像URL: card.overlayImageUrl || "",
      登録者: card.registrant || "",
      絵師: card.artist || "",
      元ネタ: card.source || "",
      imageState: card.imageState || "",
      overlayImageState: card.overlayImageState || "",
      備考: card.notes || "",
    };

    const publicRow = findRowById(publicSheet, id);
    const privateRow = findRowById(privateSheet, id);

    if (action === "update" && publicRow < 0 && privateRow < 0) {
      return { status: "not_found", message: `ID=${id} が見つかりません。` };
    }

    if (targetSheetName === SHEET_NAME_CARD_PUBLIC && privateRow > 0) {
      privateSheet.deleteRow(privateRow);
    }
    if (targetSheetName === SHEET_NAME_CARD_PRIVATE && publicRow > 0) {
      publicSheet.deleteRow(publicRow);
    }

    const targetRow = findRowById(targetSheet, id);
    const values = CARD_DB_HEADERS.map((key) => cardRow[key] || "");
    if (targetRow > 0) {
      targetSheet
        .getRange(targetRow, 1, 1, CARD_DB_HEADERS.length)
        .setValues([values]);
    } else {
      targetSheet.appendRow(values);
    }

    return {
      status: "success",
      message:
        action === "update"
          ? "カードを更新しました。"
          : "カードを作成しました。",
      id,
      scope: targetSheetName,
      updatedAt: Utilities.formatDate(
        now,
        CARD_DB_TIME_ZONE,
        "yyyy/MM/dd HH:mm:ss",
      ),
    };
  }

  if (action === "delete") {
    const id = String(payload.ID || "");
    if (!id) return { status: "error", message: "IDが必要です。" };

    const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
    const publicSheet = getOrCreateSheetByName(
      spreadsheet,
      SHEET_NAME_CARD_PUBLIC,
    );
    const privateSheet = getOrCreateSheetByName(
      spreadsheet,
      SHEET_NAME_CARD_PRIVATE,
    );
    ensureCardDbHeader(publicSheet);
    ensureCardDbHeader(privateSheet);

    const publicRow = findRowById(publicSheet, id);
    if (publicRow > 0) {
      publicSheet.deleteRow(publicRow);
      return { status: "success", message: "公開カードを削除しました。", id };
    }

    const privateRow = findRowById(privateSheet, id);
    if (privateRow > 0) {
      const owner = normalizeRegistrantName(
        privateSheet.getRange(privateRow, 13).getValue(),
      );
      const actor = normalizeRegistrantName(
        payload.registrant || payload.owner || "",
      );
      if (!actor || owner !== actor) {
        return {
          status: "forbidden",
          message: "非公開カードの削除権限がありません。",
        };
      }
      privateSheet.deleteRow(privateRow);
      return { status: "success", message: "非公開カードを削除しました。", id };
    }

    return { status: "not_found", message: `ID=${id} が見つかりません。` };
  }

  return { status: "error", message: `不正なactionです: ${action}` };
}

function getCardPublicList() {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(
    SHEET_NAME_CARD_PUBLIC,
  );
  if (!sheet) return createJsonResponse({ status: "success", data: [] });
  const values = sheet.getDataRange().getValues();
  if (values.length <= 1)
    return createJsonResponse({ status: "success", data: [] });

  const rows = values.slice(1).map((row) => mapCardRowToObject(row));
  return createJsonResponse({
    status: "success",
    data: rows.filter((r) => r.ID),
  });
}

function getCardMineList(e) {
  const registrant = normalizeRegistrantName(
    (e.parameter && e.parameter.registrant) || "",
  );
  if (!registrant) {
    return createJsonResponse({
      status: "error",
      message: "registrant パラメータが必要です。",
    });
  }

  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(
    SHEET_NAME_CARD_PRIVATE,
  );
  if (!sheet) return createJsonResponse({ status: "success", data: [] });
  const values = sheet.getDataRange().getValues();
  if (values.length <= 1)
    return createJsonResponse({ status: "success", data: [] });

  const rows = values
    .slice(1)
    .map((row) => mapCardRowToObject(row))
    .filter((row) => normalizeRegistrantName(row["登録者"]) === registrant);

  return createJsonResponse({ status: "success", data: rows });
}

function loadCardByIdWithOwnerCheck(e) {
  const id = String((e.parameter && e.parameter.id) || "");
  if (!id)
    return createJsonResponse({
      status: "error",
      message: "id パラメータが必要です。",
    });

  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  const publicSheet = spreadsheet.getSheetByName(SHEET_NAME_CARD_PUBLIC);
  const privateSheet = spreadsheet.getSheetByName(SHEET_NAME_CARD_PRIVATE);

  if (publicSheet) {
    const publicRow = findRowById(publicSheet, id);
    if (publicRow > 0) {
      const rowValues = publicSheet
        .getRange(publicRow, 1, 1, CARD_DB_HEADERS.length)
        .getValues()[0];
      return createJsonResponse({
        status: "success",
        scope: "public",
        data: mapCardRowToObject(rowValues),
      });
    }
  }

  if (privateSheet) {
    const privateRow = findRowById(privateSheet, id);
    if (privateRow > 0) {
      const rowValues = privateSheet
        .getRange(privateRow, 1, 1, CARD_DB_HEADERS.length)
        .getValues()[0];
      const card = mapCardRowToObject(rowValues);
      const owner = normalizeRegistrantName(card["登録者"]);
      const actor = normalizeRegistrantName(
        (e.parameter && e.parameter.registrant) || "",
      );
      if (!actor || owner !== actor) {
        return createJsonResponse({
          status: "forbidden",
          message: "この非公開カードへのアクセス権限がありません。",
        });
      }
      return createJsonResponse({
        status: "success",
        scope: "private",
        data: card,
      });
    }
  }

  return createJsonResponse({
    status: "not_found",
    message: "カードが見つかりません。",
  });
}

function getOrCreateSheetByName(spreadsheet, name) {
  return spreadsheet.getSheetByName(name) || spreadsheet.insertSheet(name);
}

function ensureCardDbHeader(sheet) {
  const lastRow = sheet.getLastRow();
  if (lastRow === 0) {
    sheet.appendRow(CARD_DB_HEADERS);
    return;
  }
  const currentHeader = sheet
    .getRange(1, 1, 1, CARD_DB_HEADERS.length)
    .getValues()[0];
  const needsHeader = CARD_DB_HEADERS.some(
    (h, i) => String(currentHeader[i] || "") !== h,
  );
  if (needsHeader) {
    sheet
      .getRange(1, 1, 1, CARD_DB_HEADERS.length)
      .setValues([CARD_DB_HEADERS]);
  }
}

function mapCardRowToObject(rowValues) {
  const obj = {};
  CARD_DB_HEADERS.forEach((key, idx) => {
    obj[key] = rowValues[idx] == null ? "" : rowValues[idx];
  });
  return obj;
}

function normalizeRegistrantName(name) {
  return String(name || "")
    .trim()
    .toLowerCase();
}

function findRowById(sheet, id) {
  const data = sheet.getDataRange().getValues();
  for (let i = 1; i < data.length; i++) {
    if (String(data[i][0]) === String(id)) return i + 1;
  }
  return -1;
}

function createJsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(
    ContentService.MimeType.JSON,
  );
}
