# SW2.5 モンスターデータ分析用マスター

## 目的

『Sword World 2.5 - Monstrous Lore』の魔物データを毎回PDFから再検索せず、分類別傾向・頻出能力・言語・生息地・レベル帯別傾向を再現可能な形で集計するための中間データです。

- PDF: 原典確認用
- JSON: 分析・実装用
- `sw25_monster_terms_ja.json`: 英語表記から日本語表記への確認済み辞書
- `sw25_monsters_review.json`: 未確認項目の作業キュー

## ファイル

- `sw25_monsters_master.json`
  - 魔物1体を1レコードとして格納した正規化データ
  - 現在375レコード
- `sw25_monsters_stats.json`
  - 分類別・レベル帯別・全体頻度の集計済みデータ
  - `abilities`: 個別データに出た能力見出しの出現数
  - `ability_monsters`: その能力見出しを持つ魔物レコード数
- `sw25_monster_class_common_traits.json`
  - 個別データから省略される分類共通能力・共通仕様
  - アンデッド、魔法生物、魔動機、妖精を収録
- `sw25_monster_terms_ja.json`
  - 英語表記と日本語表記の対応辞書
  - 日本語資料で確認した内容は、このファイルを直して再生成できます
- `sw25_monsters_review.json`
  - 未対応の日本語名・能力名・生息地など、追加確認が必要な項目
- `../tools/build_sw25_monsters_master.py`
  - PDFからマスター・統計・レビューJSONを再生成するスクリプト

## 収録範囲

英語PDF p.73-222の個別魔物データを対象にしています。

`1+`、`2+`、`8+`のような相対レベル表記も別レコードとして収録し、`level_raw` と `level_status` で通常レベルと区別しています。

p.223は「人族魔物データの種族変更ルール」であり、個別魔物ではないためレコードへ混ぜていません。

格納している主な項目:

- 英語名、確認済み日本語名
- 分類、レベル、掲載ページ、参照元
- 知能、知覚、反応、穢れ
- 言語、生息地
- 知名度、弱点値、弱点
- 先制値、移動速度、生命抵抗、精神抵抗
- 部位数、部位内訳、コア部位
- 特殊能力の見出し、種別記号、適用部位

## 収録しないもの

- 魔物の解説全文
- 特殊能力の説明本文全文
- 戦利品本文

分析に必要な事実と能力見出しに限定しています。元PDFそのものも成果物には含めません。

## 分類共通能力

英語PDFでは、分類共通能力が個別魔物データから省略される場合があります。

- アンデッド: p.134
- 魔法生物: p.149
- 魔動機: p.159
- 妖精: p.187

これらは `sw25_monster_class_common_traits.json` に分離しました。`sw25_monsters_stats.json` の能力頻度へは自動加算していません。個別見出しの頻度と分類共通仕様を混同しないためです。

## 日本語データの扱い

日本語名・日本語用語は、画像・既存実装・ユーザー確認済み表記だけを反映しています。

未確認項目は推測で埋めず、次の状態を保持します。

- `verified`: 日本語資料または確認済み表記
- `normalized`: 分析用に統一した表記
- `ambiguous`: 英語だけでは日本語表記を一意に決められない
- `unmapped` / `unverified`: 未確認

例として、英語の `Mountains` は日本語版で「山」「山岳」の両方になり得るため、候補だけを保持して一意に確定していません。

## ページ番号

- `source.pdf_page`: 英語PDFのページ
- `source.japanese_page_estimate`: 英語PDFページから7を引いた暫定値

日本語ページは一律に確定した値ではないので、`source.japanese_page_status` も必ず確認してください。

## 統計の数え方

`sw25_monsters_stats.json` には数え方を `counting_scope` として明記しています。

- 言語・生息地: その項目を持つ魔物レコード数
- `abilities`: 個別魔物欄に現れた能力見出しの出現数
- `ability_monsters`: 同じ魔物内の重複を1件にまとめた所持魔物数
- 分類共通能力: 別JSON参照。統計へ自動加算しない

「候補UIの優先順位」を決めるときは、原則として `ability_monsters` を使う方が安全です。

## 再生成

リポジトリのルートを `247_guild/` とした場合:

```bash
python tools/build_sw25_monsters_master.py \
  "/path/to/Sword World 2.5 - Monstrous Lore.pdf" \
  --terms data/sw25_monster_terms_ja.json \
  --out-dir data
```

必要環境:

- Python 3.10以上
- PyMuPDF (`fitz`)

## 今後の更新手順

1. 日本語画像や原典で正式表記を確認する
2. `sw25_monster_terms_ja.json` を修正する
3. 必要なら `sw25_monster_class_common_traits.json` も修正する
4. ビルドスクリプトを再実行する
5. `sw25_monsters_review.json` の未対応件数が減ったことを確認する
6. `sw25_monsters_stats.json` を自動入力ルールや頻出候補の判断材料に使う

## 現在の既知事項

- 英語版PDFそのものに表記揺れや不自然な語があります
- `Flight` は日本語の「飛行」「飛翔」を英語名だけで確定できません
- `Mountains` は「山」「山岳」を英語だけでは確定できません
- `Habitat: Ruins, Habitats, Shallow` のように、英語PDF自体に不自然な生息地表記があります。原文を残し、勝手に修正していません
- 特殊能力本文の依存部位・使用制限などは、現バージョンでは全文保存していません
- 戦闘表の各部位行は、次段階で構造化する予定です
